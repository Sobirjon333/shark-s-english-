# Local startup verification

Verified on 7 November 2026 with Node.js 24 and npm.

- Installed dependencies in a clean folder without pnpm modules.
- `npm run build`: strict TypeScript and production build passed.
- `npm run dev`: Vite started successfully.
- Homepage, IELTS route, and compiled React/CSS modules returned HTTP 200.
- `npm install` also passed in the original project after replacing the generated dependency tree with the clean npm installation.
- Added npm lockfile, Node version guidance, VS Code workspace, and startup troubleshooting.
- The source ZIP excludes generated dependencies, build output, Git history, and private hosting metadata.
