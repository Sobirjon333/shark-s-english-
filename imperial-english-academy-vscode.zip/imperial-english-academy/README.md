# Imperial English Academy

A complete, responsive frontend demonstration for a fictional premium English school in Tashkent. Original navy-and-gold branding inspired by the information hierarchy of Inter Nation, without copying its code or branding.

## Open and run in VS Code

1. Install Node.js 24 LTS with npm from https://nodejs.org/en/download if `node --version` or `npm --version` is not available. Restart VS Code after installation.
2. Extract the source ZIP if you downloaded it.
3. In VS Code choose **File → Open Folder** and select the `imperial-english-academy` folder containing `package.json`. You can also open `Imperial English Academy.code-workspace`.
4. Choose **Terminal → New Terminal** and run:

```sh
npm install
npm run dev
```

5. Open the localhost URL printed by Vite, normally http://localhost:5173.

This is a React + TypeScript application. Run it with Vite using the commands above; opening `index.html` directly or using the Live Server extension will not compile the application.

```sh
npm run build    # strict TypeScript check and production build
npm run preview  # serve the production build locally
```

Node.js 22.12 or newer is required; Node.js 24 is the tested version. For a reproducible clean install use `npm ci` with the included `package-lock.json`. pnpm is optional.

### If startup fails

- `npm: command not found` or `node: command not found`: install Node.js with npm, then restart the VS Code terminal.
- `ENOENT ... package.json`: open the project folder containing `package.json` before running commands.
- A blank page when opening `index.html`: run `npm run dev` and open the printed localhost URL.
- Port 5173 already in use: Vite prints the next available port; use the URL shown in your terminal.
- Old dependencies: remove the project's `node_modules` folder and run `npm ci` again.

The Vite module runner loads configuration directly. No API key, account, ChatGPT sign-in, environment file, or backend is needed to run the local project.

## Included

- Home, About, Courses, Teachers, Results, Gallery, Branches, Contact, Free Lesson, privacy/demo notice, and 404 pages.
- Seven individual course pages with audiences, outcomes, sample schedules, levels, and sample tuition.
- Eight fictional teacher profiles with modal biographies and speciality filters.
- English, Russian, and Uzbek content; English is the default. Language preference persists in browser local storage.
- Responsive sticky navigation, mobile menu, animated counters, course and teacher filters, FAQ accordion, gallery lightbox, route transitions, and scroll-to-top.
- Trial and contact forms with Uzbekistan phone validation, inline errors, loading state, confirmation screen, and toast.
- Keyboard accessible dialogs with focus trapping, Escape handling, focus restoration, labelled fields, skip navigation, and reduced-motion support.
- Locally bundled illustrative photographs and fonts, with no external image or font requests during normal use.

## Project structure

- `src/components/` — layout, cards, registration form, and shared UI.
- `src/pages/` — page components and home sections.
- `src/data.ts` — translated fictional courses, teachers, students, branches, and FAQs.
- `src/i18n.tsx` — typed three-language content and preference provider.
- `src/styles.css` — responsive design system and locally hosted font faces.
- `public/images/`, `public/fonts/` — local assets.

## Demonstration boundaries

This is a frontend concept, not an operating academy. All names, qualifications, scores, testimonials, school statistics, prices, and branches are fictional. IELTS outcomes are not guaranteed. No accreditation or university affiliation is claimed. Photography from Unsplash is illustrative and does not depict actual Imperial students, teachers, or facilities. Google fonts Manrope and DM Sans are bundled locally under their open font licenses.

Forms only validate in memory in the visitor's browser. They do not send requests, persist personal information, create bookings, or imply that a real advisor will contact the visitor. Contact numbers and the `.example` email domain are intentionally inactive. Social links open platform home pages; map links open general districts, never fabricated academy addresses.

## Deployment

`npm run build` produces `dist/`. Configure any static host to serve `index.html` for application paths (SPA history fallback). Sites detects the static SPA. There is no backend, API key, database, or environment variable requirement.

## Verification

The production build performs strict TypeScript checking. Browser QA covers desktop and iPhone layouts, all route families, course and teacher filters, profile and gallery dialogs, English/Russian/Uzbek switching, form errors and successful demo validation. See `STARTUP-CHECKS.md` for the latest local startup verification.
