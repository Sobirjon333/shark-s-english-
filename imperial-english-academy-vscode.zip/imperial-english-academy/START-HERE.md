# Open this project in VS Code

1. Install **Node.js 24 LTS with npm** from https://nodejs.org/en/download.
2. Open this folder in VS Code: **File → Open Folder**. Choose the folder containing `package.json`.
3. Open **Terminal → New Terminal** and run:

```sh
npm install
npm run dev
```

4. Open the localhost address printed in the terminal.

The complete editable source is in `src/`, including all pages, styles, translations, and components. Images and fonts are in `public/`.

Open `README.md` for troubleshooting and the full project guide.
