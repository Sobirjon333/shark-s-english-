import { useCallback, useEffect, useState } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { ArrowRight, Award, CheckCircle2, X } from "lucide-react";
import { useLanguage, words } from "./i18n";
import { courses } from "./data";
import type { Teacher } from "./data";
import { Header, Footer, ScrollTop } from "./components/Layout";
import { Dialog } from "./components/ui";
import RegistrationForm from "./components/RegistrationForm";
import Home from "./pages/Home";
import {
  AboutPage,
  CoursesPage,
  CourseDetail,
  TeachersPage,
  ResultsPage,
  GalleryPage,
  BranchesPage,
  ContactPage,
  TrialPage,
  PrivacyPage,
  NotFound,
} from "./pages/Pages";
export default function App() {
  const { t, language } = useLanguage();
  const location = useLocation();
  const reduced = useReducedMotion();
  const [trial, setTrial] = useState<{ course?: string } | null>(null);
  const [teacher, setTeacher] = useState<Teacher | null>(null);
  const [toast, setToast] = useState(false);
  const onTrial = useCallback((course?: string) => setTrial({ course }), []);
  const closeTrial = useCallback(() => setTrial(null), []);
  const closeTeacher = useCallback(() => setTeacher(null), []);
  const onSuccess = useCallback(() => setToast(true), []);
  useEffect(() => {
    if (toast) {
      const id = setTimeout(() => setToast(false), 5000);
      return () => clearTimeout(id);
    }
  }, [toast]);
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" });
  }, [location.pathname]);
  useEffect(() => {
    const titles: Record<string, string> = {
      "/": t([
        "Your English. Your Future.",
        "Ваш английский. Ваше будущее.",
        "Ingliz tilingiz. Kelajagingiz.",
      ]),
      "/about": t(words.about),
      "/courses": t(words.courses),
      "/teachers": t(words.teachers),
      "/results": t(words.results),
      "/gallery": t(words.gallery),
      "/branches": t(words.branches),
      "/contact": t(words.contact),
      "/free-lesson": t(words.trial),
      "/privacy": t([
        "Demo & privacy",
        "Демо и конфиденциальность",
        "Namuna va maxfiylik",
      ]),
    };
    document.title = `${titles[location.pathname] || (courses.find((c) => location.pathname === `/courses/${c.id}`) ? t(courses.find((c) => location.pathname === `/courses/${c.id}`)!.title) : t(words.notfound))} | Imperial English Academy`;
  }, [location.pathname, language, t]);
  return (
    <>
      <a className="skip-link" href="#main">
        {t(["Skip to content", "К содержимому", "Asosiy mazmunga"])}
      </a>
      <Header onTrial={() => onTrial()} />
      <main id="main">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={location.pathname}
            initial={reduced ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
          >
            <Routes location={location}>
              <Route
                path="/"
                element={
                  <Home onTrial={() => onTrial()} onProfile={setTeacher} />
                }
              />
              <Route path="/about" element={<AboutPage onTrial={onTrial} />} />
              <Route
                path="/courses"
                element={<CoursesPage onTrial={onTrial} />}
              />
              <Route
                path="/courses/:id"
                element={<CourseDetail onTrial={onTrial} />}
              />
              <Route
                path="/teachers"
                element={
                  <TeachersPage
                    onTrial={() => onTrial()}
                    onProfile={setTeacher}
                  />
                }
              />
              <Route
                path="/results"
                element={<ResultsPage onTrial={onTrial} />}
              />
              <Route path="/gallery" element={<GalleryPage />} />
              <Route
                path="/branches"
                element={<BranchesPage onTrial={onTrial} />}
              />
              <Route
                path="/contact"
                element={<ContactPage onSuccess={onSuccess} />}
              />
              <Route
                path="/free-lesson"
                element={<TrialPage onSuccess={onSuccess} />}
              />
              <Route path="/privacy" element={<PrivacyPage />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </motion.div>
        </AnimatePresence>
      </main>
      <Footer onTrial={() => onTrial()} />
      <ScrollTop />
      {trial && (
        <Dialog
          title={t(words.trial)}
          onClose={closeTrial}
          className="trial-dialog"
        >
          <p className="eyebrow">
            <span />{" "}
            {t(["YOUR NEXT CHAPTER", "ВАША НОВАЯ ГЛАВА", "YANGI BOSQICHINGIZ"])}
          </p>
          <h2>
            {t([
              "Let’s begin with a hello.",
              "Начнём с hello.",
              "Hello’dan boshlaymiz.",
            ])}
          </h2>
          <p className="dialog-description">
            {t([
              "Find your level. Meet your possibilities. Try our demo registration.",
              "Узнайте свой уровень. Откройте возможности. Попробуйте демо-регистрацию.",
              "Darajangizni biling. Imkoniyatlarni oching. Namuna ro‘yxatdan o‘tishni sinang.",
            ])}
          </p>
          <RegistrationForm
            initialCourse={trial.course}
            onSuccess={onSuccess}
          />
        </Dialog>
      )}
      {teacher && (
        <Dialog
          title={teacher.name}
          onClose={closeTeacher}
          className="profile-dialog"
        >
          <img
            className="profile-photo"
            src={`/images/${teacher.image}.jpg`}
            alt={teacher.name}
          />
          <div className="profile-content">
            <p className="eyebrow">{t(teacher.role)}</p>
            <h2>{teacher.name}</h2>
            <div className="profile-chips">
              {teacher.score && (
                <span>
                  <Award size={16} />
                  IELTS {teacher.score}
                </span>
              )}
              <span>
                {teacher.years} {t(words.years)}
              </span>
            </div>
            <h3>{teacher.qualification}</h3>
            <p>{t(teacher.bio)}</p>
            <p className="demo-note">{t(words.demoPeople)}</p>
            <button
              className="button gold"
              onClick={() => {
                closeTeacher();
                onTrial();
              }}
            >
              {t(words.trial)}
              <ArrowRight size={17} />
            </button>
          </div>
        </Dialog>
      )}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 25 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 15 }}
            className="toast"
            role="status"
          >
            <CheckCircle2 size={22} />
            <span>
              {t([
                "Demo validated. No data sent.",
                "Демо проверено. Данные не отправлены.",
                "Namuna tekshirildi. Ma’lumot yuborilmadi.",
              ])}
            </span>
            <button
              className="icon-button"
              onClick={() => setToast(false)}
              aria-label={t(words.close)}
            >
              <X size={17} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
