import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Clock3,
  MapPin,
  Phone,
  Mail,
  Send,
  Instagram,
  UsersRound,
  GraduationCap,
  Heart,
  Target,
  Compass,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { courses, teachers, branches, gallery } from "../data";
import type { Teacher } from "../data";
import { useLanguage, words } from "../i18n";
import {
  PageHero,
  SectionHeading,
  Reveal,
  CTA,
  CheckList,
  DemoNote,
  Dialog,
  ArrowLink,
} from "../components/ui";
import { CourseCard, TeacherCard } from "../components/Cards";
import RegistrationForm from "../components/RegistrationForm";
import { FAQ, Statistics, ResultsSection } from "./Home";
type TrialProps = { onTrial: (course?: string) => void };
export function CoursesPage({ onTrial }: TrialProps) {
  const { t } = useLanguage();
  const [filter, setFilter] = useState("all");
  const filters = [
    ["all", words.all],
    [
      "adults",
      ["Adults & teens", "Взрослые и подростки", "Kattalar va o‘smirlar"],
    ],
    ["kids", ["Young learners", "Дети", "Bolalar"]],
    ["online", ["Online learning", "Онлайн-обучение", "Onlayn ta’lim"]],
  ] as const;
  return (
    <>
      <PageHero
        eyebrow={t([
          "A COURSE FOR YOUR NEXT CHAPTER",
          "КУРС ДЛЯ НОВОГО ЭТАПА",
          "YANGI BOSQICH UCHUN KURS",
        ])}
        title={t([
          "Where do you want English to take you?",
          "Куда вас приведёт английский?",
          "Ingliz tili sizni qayerga yetaklasin?",
        ])}
        text={t([
          "Seven ways to grow. One commitment to your progress. Find the programme that fits your life and your ambitions.",
          "Семь путей роста. Одна цель — ваш прогресс. Выберите программу для вашей жизни и ваших амбиций.",
          "Rivojlanishning yetti yo‘li. Bitta maqsad — sizning o‘sishingiz. Hayotingiz va orzularingizga mos dastur toping.",
        ])}
      />
      <section className="section">
        <div className="container">
          <div
            className="filter-bar"
            aria-label={t([
              "Filter courses",
              "Фильтр курсов",
              "Kurslarni saralash",
            ])}
          >
            {filters.map(([key, label]) => (
              <button
                key={key}
                className={filter === key ? "active" : ""}
                aria-pressed={filter === key}
                onClick={() => setFilter(key)}
              >
                {t(label)}
              </button>
            ))}
            <span>
              {
                courses.filter((c) => filter === "all" || c.category === filter)
                  .length
              }{" "}
              {t(words.courses).toLowerCase()}
            </span>
          </div>
          <div className="course-grid">
            {courses
              .filter((c) => filter === "all" || c.category === filter)
              .map((c) => (
                <Reveal key={c.id}>
                  <CourseCard course={c} index={courses.indexOf(c)} />
                </Reveal>
              ))}
          </div>
          <p className="demo-note">
            {t([
              "All programmes, schedules, and prices are illustrative. IELTS outcomes are not guaranteed.",
              "Все программы, расписания и цены приведены для примера. Балл IELTS не гарантируется.",
              "Dasturlar, jadvallar va narxlar namuna uchun. IELTS natijasi kafolatlanmaydi.",
            ])}
          </p>
        </div>
      </section>
      <FAQ />
      <CTA onTrial={() => onTrial()} />
    </>
  );
}
export function CourseDetail({ onTrial }: TrialProps) {
  const { id } = useParams();
  const { t } = useLanguage();
  const c = courses.find((c) => c.id === id);
  if (!c) return <NotFound />;
  return (
    <>
      <PageHero
        eyebrow={t(c.tag)}
        title={t(c.title)}
        text={t(c.description)}
        image={c.image}
      />
      <section className="section">
        <div className="container course-detail-layout">
          <div>
            <Link to="/courses" className="back-link">
              <ArrowLeft size={16} />
              {t(words.back)}
            </Link>
            <h2>
              {t([
                "A clear path. A confident you.",
                "Понятный путь. Уверенность в себе.",
                "Aniq yo‘l. Ishonchli siz.",
              ])}
            </h2>
            <p className="large-body">{t(c.audience)}</p>
            <div className="detail-features">
              <div>
                <Clock3 />
                <small>{t(words.duration)}</small>
                <strong>{t(c.duration)}</strong>
              </div>
              <div>
                <GraduationCap />
                <small>{t(words.level)}</small>
                <strong>{c.level}</strong>
              </div>
              <div>
                <UsersRound />
                <small>{t(words.group)}</small>
                <strong>8–12 {t(["learners", "студентов", "o‘quvchi"])}</strong>
              </div>
            </div>
            <h3 className="detail-subtitle">{t(words.outcomes)}</h3>
            <CheckList items={c.outcomes.map(t)} />
            <h3 className="detail-subtitle">{t(words.schedule)}</h3>
            <div className="schedule-box">
              <Clock3 size={22} />
              <div>
                <strong>{t(c.schedule)}</strong>
                <p>
                  {c.id === "kids-english"
                    ? t([
                        "60-minute lessons",
                        "Уроки по 60 минут",
                        "60 daqiqalik darslar",
                      ])
                    : t(words.minutes)}
                </p>
              </div>
            </div>
            <p className="demo-note">
              {t([
                "A sample programme, not a live offer. Availability and individual progress vary. No exam score is guaranteed.",
                "Пример программы, а не действующее предложение. Доступность и прогресс индивидуальны. Баллы не гарантируются.",
                "Bu jonli taklif emas, dastur namunasi. Mavjudlik va rivojlanish individual. Imtihon ballari kafolatlanmaydi.",
              ])}
            </p>
          </div>
          <aside className="enrollment-card">
            <p className="eyebrow">{t(words.tuition)}</p>
            <strong className="course-price">
              {c.price}
              <small>UZS{t(words.month)}</small>
            </strong>
            <CheckList
              items={[
                t([
                  "Personal learning plan",
                  "Индивидуальный учебный план",
                  "Shaxsiy o‘quv rejasi",
                ]),
                t([
                  "Supportive teacher feedback",
                  "Обратная связь преподавателя",
                  "Ustoz fikr-mulohazalari",
                ]),
                t([
                  "Progress checks included",
                  "Проверка прогресса включена",
                  "Rivojlanishni tekshirish",
                ]),
              ]}
            />
            <button className="button gold" onClick={() => onTrial(c.id)}>
              {t(words.enroll)}
              <ArrowUpRight size={17} />
            </button>
            <button className="text-button" onClick={() => onTrial(c.id)}>
              {t(words.trial)}
              <ArrowRight size={16} />
            </button>
            <span className="sample-pill">
              {t([
                "Demo programme & pricing",
                "Демо-программа и цены",
                "Namuna dastur va narxlar",
              ])}
            </span>
          </aside>
        </div>
      </section>
      <section className="section related-courses">
        <div className="container">
          <SectionHeading
            eyebrow={t([
              "KEEP EXPLORING",
              "ПРОДОЛЖАЙТЕ ИСКАТЬ",
              "IZLANISHDA DAVOM ETING",
            ])}
            title={t([
              "Another way forward.",
              "Другой путь вперёд.",
              "Olg‘a yana bir yo‘l.",
            ])}
          />
          <div className="course-grid">
            {courses
              .filter((x) => x.id !== c.id)
              .slice(0, 3)
              .map((x, i) => (
                <CourseCard course={x} index={i} key={x.id} />
              ))}
          </div>
        </div>
      </section>
    </>
  );
}
export function TeachersPage({
  onProfile,
  onTrial,
}: {
  onProfile: (teacher: Teacher) => void;
  onTrial: () => void;
}) {
  const { t } = useLanguage();
  const [filter, setFilter] = useState("all");
  const filters = [
    ["all", words.all],
    ["IELTS", ["IELTS", "IELTS", "IELTS"]],
    ["General", ["General English", "Общий английский", "Umumiy ingliz tili"]],
    ["Kids", ["Young learners", "Дети", "Bolalar"]],
    [
      "Business",
      ["Business English", "Деловой английский", "Biznes ingliz tili"],
    ],
  ] as const;
  return (
    <>
      <PageHero
        eyebrow={t([
          "THE PEOPLE BEHIND YOUR PROGRESS",
          "ЛЮДИ, КОТОРЫЕ ПОМОГАЮТ РАСТИ",
          "RIVOJLANISHINGIZ ORTIDAGI INSONLAR",
        ])}
        title={t([
          "Great teachers. Even better humans.",
          "Отличные учителя. Замечательные люди.",
          "Ajoyib ustozlar. Yaxshi insonlar.",
        ])}
        text={t([
          "Passionate about language. Invested in your journey. Meet the fictional mentors who bring the Imperial experience to life.",
          "Увлечённые языком и вашим успехом. Познакомьтесь с вымышленными наставниками Imperial.",
          "Tilga va sizning yo‘lingizga mehr qo‘yganlar. Imperial’ning xayoliy ustozlari bilan tanishing.",
        ])}
      />
      <section className="section">
        <div className="container">
          <div className="filter-bar">
            {filters.map(([key, label]) => (
              <button
                key={key}
                aria-pressed={filter === key}
                className={filter === key ? "active" : ""}
                onClick={() => setFilter(key)}
              >
                {t(label)}
              </button>
            ))}
          </div>
          <div className="teacher-grid">
            {teachers
              .filter(
                (teacher) => filter === "all" || teacher.category === filter,
              )
              .map((teacher) => (
                <Reveal key={teacher.id}>
                  <TeacherCard teacher={teacher} onProfile={onProfile} />
                </Reveal>
              ))}
          </div>
          <DemoNote />
        </div>
      </section>
      <CTA onTrial={onTrial} />
    </>
  );
}
export function AboutPage({ onTrial }: TrialProps) {
  const { t } = useLanguage();
  return (
    <>
      <PageHero
        eyebrow={t([
          "ROOTED IN TASHKENT. OPEN TO THE WORLD.",
          "ИЗ ТАШКЕНТА — В МИР.",
          "TOSHKENTDAN DUNYOGA.",
        ])}
        title={t([
          "A better future begins with a conversation.",
          "Лучшее будущее начинается с разговора.",
          "Yaxshi kelajak suhbatdan boshlanadi.",
        ])}
        text={t([
          "We imagined an academy where excellent teaching feels personal, and every learner feels they belong. Welcome to Imperial.",
          "Мы представили академию, где отличное обучение сочетается с личным подходом, а каждый студент чувствует себя своим. Добро пожаловать в Imperial.",
          "Biz sifatli ta’lim shaxsiy e’tibor bilan uyg‘unlashgan, har bir o‘quvchi o‘z o‘rnini topadigan akademiyani tasavvur qildik. Imperial’ga xush kelibsiz.",
        ])}
        image="classroom"
      />
      <section className="section">
        <div className="container about-story">
          <div>
            <p className="eyebrow">
              <span />
              {t(["OUR STORY", "НАША ИСТОРИЯ", "BIZNING TARIXIMIZ"])}
            </p>
            <h2>
              {t([
                "Built around people. Driven by possibility.",
                "В центре — люди. Впереди — возможности.",
                "Insonlar uchun. Imkoniyatlar sari.",
              ])}
            </h2>
          </div>
          <div>
            <p className="large-body">
              {t([
                "Imperial English Academy is a fictional school concept inspired by the energy, curiosity, and ambition of Tashkent. Our story starts with a simple idea: learning English should open your world.",
                "Imperial English Academy — концепция вымышленной школы, вдохновлённая энергией и амбициями Ташкента. Наша история начинается с идеи: английский должен открывать мир.",
                "Imperial English Academy — Toshkentning g‘ayrati va orzularidan ilhomlangan xayoliy maktab konsepsiyasi. Tariximiz oddiy g‘oyadan boshlanadi: ingliz tili dunyongizni ochishi kerak.",
              ])}
            </p>
            <p>
              {t([
                "In this imagined academy, thoughtful classrooms, small groups, and dedicated mentors come together. We celebrate progress over perfection, and believe a welcoming community makes brave learning possible.",
                "В этой воображаемой академии объединены удобные классы, небольшие группы и преданные наставники. Мы ценим прогресс больше совершенства и верим в силу дружного сообщества.",
                "Bu xayoliy akademiyada qulay sinfxonalar, kichik guruhlar va fidoyi ustozlar birlashadi. Mukammallikdan ko‘ra rivojlanishni qadrlaymiz va do‘stona muhitga ishonamiz.",
              ])}
            </p>
            <span className="sample-pill">{t(words.demo)}</span>
          </div>
        </div>
      </section>
      <Statistics />
      <section className="section about-values">
        <div className="container">
          <SectionHeading
            eyebrow={t([
              "WHAT WE BELIEVE",
              "ВО ЧТО МЫ ВЕРИМ",
              "BIZNING ISHONCHIMIZ",
            ])}
            title={t([
              "Purpose in every lesson.",
              "Смысл в каждом уроке.",
              "Har bir darsda maqsad.",
            ])}
          />
          <div className="values-grid">
            {[
              {
                Icon: Target,
                title: [
                  "Our mission",
                  "Наша миссия",
                  "Bizning vazifamiz",
                ] as const,
                body: [
                  "Make purposeful English learning personal, approachable, and connected to each learner’s goals.",
                  "Сделать изучение английского осмысленным, доступным и связанным с целями каждого студента.",
                  "Ingliz tilini o‘rganishni har bir o‘quvchining maqsadiga mos, mazmunli va qulay qilish.",
                ] as const,
              },
              {
                Icon: Compass,
                title: [
                  "Our vision",
                  "Наше видение",
                  "Bizning qarashimiz",
                ] as const,
                body: [
                  "A generation of confident communicators who connect Tashkent with opportunities around the world.",
                  "Поколение уверенных людей, которые связывают Ташкент с возможностями по всему миру.",
                  "Toshkentni dunyo imkoniyatlari bilan bog‘laydigan ishonchli muloqotchilar avlodi.",
                ] as const,
              },
              {
                Icon: Heart,
                title: [
                  "Our philosophy",
                  "Наша философия",
                  "Bizning falsafamiz",
                ] as const,
                body: [
                  "Practise with purpose. Learn from mistakes. Support each other. Let curiosity lead the way.",
                  "Практикуйтесь осмысленно. Учитесь на ошибках. Поддерживайте друг друга. Следуйте любопытству.",
                  "Maqsad bilan mashq qiling. Xatolardan o‘rganing. Bir-biringizni qo‘llang. Qiziqish ortidan boring.",
                ] as const,
              },
            ].map(({ Icon, title, body }, i) => (
              <Reveal className="value-card" key={i}>
                <span>
                  <Icon size={27} />
                </span>
                <small>0{i + 1}</small>
                <h3>{t(title)}</h3>
                <p>{t(body)}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <section className="section">
        <div className="container approach-layout">
          <img
            src="/images/general.jpg"
            alt={t([
              "Students learning together",
              "Совместное обучение",
              "Birgalikda o‘rganish",
            ])}
            loading="lazy"
          />
          <div>
            <p className="eyebrow">
              <span />
              {t([
                "THOUGHTFUL BY DESIGN",
                "ПРОДУМАННЫЙ ПОДХОД",
                "PUXTA YONDASHUV",
              ])}
            </p>
            <h2>
              {t([
                "A clear path, with room to be you.",
                "Понятный путь с учётом ваших особенностей.",
                "Sizga mos aniq yo‘l.",
              ])}
            </h2>
            <CheckList
              items={[
                t([
                  "A level conversation and personal goal setting",
                  "Определение уровня и постановка личных целей",
                  "Darajani aniqlash va shaxsiy maqsadlar",
                ]),
                t([
                  "Balanced practice in all four language skills",
                  "Сбалансированная практика четырёх навыков",
                  "To‘rtta til ko‘nikmasini teng rivojlantirish",
                ]),
                t([
                  "Regular feedback and practical progress reviews",
                  "Регулярная обратная связь и оценка прогресса",
                  "Muntazam fikrlar va natijalarni tekshirish",
                ]),
                t([
                  "Social learning through clubs and creative projects",
                  "Обучение через клубы и творческие проекты",
                  "Klublar va ijodiy loyihalar orqali o‘rganish",
                ]),
              ]}
            />
            <ArrowLink to="/gallery">
              {t([
                "Explore our spaces",
                "Наши пространства",
                "Makonlarimizni ko‘ring",
              ])}
            </ArrowLink>
            <p className="demo-note">
              {t([
                "No real accreditation, university affiliation, or licensed curriculum is claimed. All academy facilities shown are illustrative photography.",
                "Реальная аккредитация, партнёрство с вузами и лицензированные программы не заявляются. Все фотографии помещений иллюстративные.",
                "Haqiqiy akkreditatsiya, universitet hamkorligi yoki litsenziyalangan dastur da’vo qilinmaydi. Barcha bino suratlari tasviriy.",
              ])}
            </p>
          </div>
        </div>
      </section>
      <section className="section about-gallery">
        <div className="container">
          <SectionHeading
            eyebrow={t([
              "SPACES FOR BIG IDEAS",
              "ПРОСТРАНСТВА ДЛЯ БОЛЬШИХ ИДЕЙ",
              "KATTA G‘OYALAR UCHUN MAKON",
            ])}
            title={t([
              "Make yourself at home.",
              "Почувствуйте себя как дома.",
              "O‘zingizni uydagidek his qiling.",
            ])}
          />
          <div className="about-photo-grid">
            {["classroom", "club", "kids"].map((img) => (
              <Link to="/gallery" key={img} aria-label={t(words.gallery)}>
                <img
                  src={`/images/${img}.jpg`}
                  alt={t([
                    "Illustrative academy life",
                    "Иллюстрация жизни академии",
                    "Akademiya hayoti namunasi",
                  ])}
                  loading="lazy"
                />
              </Link>
            ))}
          </div>
        </div>
      </section>
      <CTA onTrial={() => onTrial()} />
    </>
  );
}
export function ResultsPage({ onTrial }: TrialProps) {
  const { t } = useLanguage();
  return (
    <>
      <PageHero
        eyebrow={t([
          "PROGRESS WORTH CELEBRATING",
          "ПРОГРЕСС, КОТОРЫЙ ВДОХНОВЛЯЕТ",
          "NISHONLASHGA ARZIYDIGAN NATIJALAR",
        ])}
        title={t([
          "Imagine your own success story.",
          "Представьте свою историю успеха.",
          "Muvaffaqiyat hikoyangizni tasavvur qiling.",
        ])}
        text={t([
          "A score is only part of the story. Confidence, new opportunities, and a wider world are what come next. These are fictional examples, not verified results.",
          "Балл — лишь часть истории. Дальше — уверенность, новые возможности и большой мир. Эти примеры вымышлены, а не подтверждены.",
          "Ball — hikoyaning bir qismi. Keyin ishonch, imkoniyatlar va keng dunyo keladi. Bu haqiqiy natijalar emas, xayoliy misollar.",
        ])}
      />
      <ResultsSection full />
      <section className="section">
        <div className="container result-method">
          <GraduationCap size={48} />
          <h2>
            {t([
              "Your progress is personal.",
              "Ваш прогресс индивидуален.",
              "Rivojlanishingiz o‘ziga xos.",
            ])}
          </h2>
          <p>
            {t([
              "The sample journeys above illustrate possible learning goals. Actual IELTS performance depends on your starting point, consistent practice, and exam-day performance. Imperial is a fictional academy and guarantees no score.",
              "Примеры выше иллюстрируют возможные цели. Реальный результат IELTS зависит от начального уровня, практики и самого экзамена. Imperial — вымышленная академия, баллы не гарантируются.",
              "Yuqoridagi namunalar maqsadlarni ko‘rsatadi. IELTS natijasi boshlang‘ich daraja, muntazam mashqlar va imtihonga bog‘liq. Imperial xayoliy akademiya bo‘lib, ball kafolatlamaydi.",
            ])}
          </p>
          <Link to="/courses/ielts-preparation" className="button navy">
            {t([
              "Discover IELTS preparation",
              "Подготовка к IELTS",
              "IELTS tayyorlovni ko‘ring",
            ])}
            <ArrowRight size={18} />
          </Link>
        </div>
      </section>
      <CTA onTrial={() => onTrial()} />
    </>
  );
}
export function GalleryPage() {
  const { t } = useLanguage();
  const [filter, setFilter] = useState("all");
  const [view, setView] = useState<number | null>(null);
  const filtered = gallery.filter(
    (g) => filter === "all" || g.category === filter,
  );
  const categories = [
    ["all", words.all],
    ["Spaces", ["Our spaces", "Наши пространства", "Makonlarimiz"]],
    ["Learning", ["In the classroom", "На уроках", "Darslarda"]],
    [
      "Community",
      ["Community & events", "Сообщество и события", "Hamjamiyat va tadbirlar"],
    ],
  ] as const;
  return (
    <>
      <PageHero
        eyebrow={t([
          "A GLIMPSE OF THE EVERYDAY",
          "ВЗГЛЯД НА ПОВСЕДНЕВНОСТЬ",
          "KUNDALIK HAYOTGA NAZAR",
        ])}
        title={t([
          "This is what belonging looks like.",
          "Вот как выглядит своё место.",
          "O‘z makoningiz shunday ko‘rinadi.",
        ])}
        text={t([
          "Good conversations. Shared discoveries. Spaces that inspire. Explore the visual world of our fictional academy through illustrative photography.",
          "Хорошие разговоры. Общие открытия. Вдохновляющие пространства. Иллюстративные фотографии вымышленной академии.",
          "Yaxshi suhbatlar. Birgalikdagi kashfiyotlar. Ilhomlantiruvchi makonlar. Xayoliy akademiyamizning tasviriy suratlarini ko‘ring.",
        ])}
      />
      <section className="section">
        <div className="container">
          <div className="filter-bar">
            {categories.map(([key, label]) => (
              <button
                key={key}
                className={filter === key ? "active" : ""}
                aria-pressed={filter === key}
                onClick={() => setFilter(key)}
              >
                {t(label)}
              </button>
            ))}
          </div>
          <div className="gallery-grid">
            {filtered.map((g, i) => (
              <button
                className="gallery-item"
                key={g.title[0]}
                onClick={() => setView(i)}
                aria-label={`${t(["View image", "Посмотреть фото", "Suratni ko‘rish"])}: ${t(g.title)}`}
              >
                <img
                  src={`/images/${g.image}.jpg`}
                  alt={t(g.title)}
                  loading="lazy"
                />
                <div>
                  <span>{t(g.title)}</span>
                  <ArrowUpRight size={22} />
                </div>
              </button>
            ))}
          </div>
          <p className="demo-note">
            {t([
              "Illustrative stock photography from Unsplash. These are not photographs of an actual Imperial campus.",
              "Иллюстративные стоковые фотографии Unsplash. Это не реальные фотографии кампуса Imperial.",
              "Unsplash’dan tasviriy suratlar. Bular haqiqiy Imperial binosi suratlari emas.",
            ])}
          </p>
        </div>
      </section>
      {view !== null && (
        <Dialog
          title={t(filtered[view].title)}
          onClose={() => setView(null)}
          className="lightbox"
        >
          <img
            src={`/images/${filtered[view].image}.jpg`}
            alt={t(filtered[view].title)}
          />
          <div className="lightbox-controls">
            <button
              className="icon-button"
              onClick={() =>
                setView((view - 1 + filtered.length) % filtered.length)
              }
              aria-label={t([
                "Previous image",
                "Предыдущее фото",
                "Oldingi surat",
              ])}
            >
              <ChevronLeft />
            </button>
            <p>
              {t(filtered[view].title)}
              <small>
                {view + 1} / {filtered.length}
              </small>
            </p>
            <button
              className="icon-button"
              onClick={() => setView((view + 1) % filtered.length)}
              aria-label={t(["Next image", "Следующее фото", "Keyingi surat"])}
            >
              <ChevronRight />
            </button>
          </div>
        </Dialog>
      )}
    </>
  );
}
export function MapPlaceholder({ district }: { district?: string }) {
  const { t } = useLanguage();
  return (
    <div className="map-placeholder">
      <div className="map-roads" />
      <div className="map-pin">
        <MapPin size={27} />
      </div>
      <span>{district || t(["Tashkent", "Ташкент", "Toshkent"])}</span>
      <small>
        {t([
          "Illustrative map · no verified academy location",
          "Пример карты · адрес академии не подтверждён",
          "Namuna xarita · akademiya manzili tasdiqlanmagan",
        ])}
      </small>
    </div>
  );
}
export function BranchesPage({ onTrial }: TrialProps) {
  const { t } = useLanguage();
  return (
    <>
      <PageHero
        eyebrow={t([
          "YOUR NEIGHBOURHOOD. YOUR ACADEMY.",
          "ВАШ РАЙОН. ВАША АКАДЕМИЯ.",
          "SIZNING TUMANINGIZ. SIZNING AKADEMIYANGIZ.",
        ])}
        title={t(words.find)}
        text={t([
          "Three imagined spaces across Tashkent, one welcoming community. All branches are fictional examples; street addresses are intentionally unassigned.",
          "Три воображаемых пространства Ташкента, одно дружное сообщество. Все филиалы вымышлены, точные адреса не назначены.",
          "Toshkent bo‘ylab uchta xayoliy makon va bitta do‘stona hamjamiyat. Barcha filiallar namuna, aniq ko‘cha manzillari belgilanmagan.",
        ])}
      />
      <section className="section">
        <div className="container branch-grid">
          {branches.map((b) => (
            <Reveal className="branch-card" key={b.id}>
              <img
                src={`/images/${b.image}.jpg`}
                alt={t([
                  "Illustrative classroom",
                  "Иллюстрация класса",
                  "Namuna sinfxona",
                ])}
                loading="lazy"
              />
              <div className="branch-body">
                <span className="sample-pill">{t(words.sample)}</span>
                <h2>{b.name}</h2>
                <p>
                  <MapPin size={17} />
                  {t(b.district)}, {t(["Tashkent", "Ташкент", "Toshkent"])}
                </p>
                <p className="muted">
                  {t([
                    "Street address to be confirmed — demo only",
                    "Адрес будет уточнён — только демо",
                    "Ko‘cha manzili belgilanmagan — namuna",
                  ])}
                </p>
                <p>
                  <Clock3 size={17} />
                  {t([
                    "Mon–Sat · 08:00–21:00",
                    "Пн–Сб · 08:00–21:00",
                    "Du–Sha · 08:00–21:00",
                  ])}
                </p>
                <p>
                  <Phone size={17} />
                  +998 (00) 000-00-00
                </p>
                <small>
                  {t([
                    "Sample phone · not connected",
                    "Пример телефона · не подключён",
                    "Namuna telefon · ulanmagan",
                  ])}
                </small>
                <MapPlaceholder district={t(b.district)} />
                <a
                  className="course-link"
                  href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(b.name + " district Tashkent Uzbekistan")}`}
                  target="_blank"
                  rel="noreferrer"
                >
                  {t(words.directions)}
                  <ArrowUpRight size={17} />
                </a>
                <p className="demo-note">
                  {t([
                    "Opens the general district, not directions to an academy.",
                    "Открывается район, а не маршрут к академии.",
                    "Akademiyaga yo‘nalish emas, umumiy tuman ochiladi.",
                  ])}
                </p>
                <button className="button navy" onClick={() => onTrial()}>
                  {t(words.trial)}
                  <ArrowRight size={17} />
                </button>
              </div>
            </Reveal>
          ))}
        </div>
      </section>
    </>
  );
}
export function ContactPage({ onSuccess }: { onSuccess: () => void }) {
  const { t } = useLanguage();
  return (
    <>
      <PageHero
        eyebrow={t([
          "LET’S START A CONVERSATION",
          "ДАВАЙТЕ ПОГОВОРИМ",
          "KELING, SUHBATLASHAMIZ",
        ])}
        title={t([
          "Your goals. Our next conversation.",
          "Ваши цели. Наш следующий разговор.",
          "Sizning maqsadlaringiz. Bizning suhbatimiz.",
        ])}
        text={t([
          "A question, an ambition, or a fresh start. We’d love to hear it. Explore this demo contact experience.",
          "Вопрос, мечта или новое начало. Мы готовы выслушать. Попробуйте демонстрационную форму связи.",
          "Savol, orzu yoki yangi boshlanish. Sizni tinglashga tayyormiz. Namuna aloqa shaklini sinab ko‘ring.",
        ])}
      />
      <section className="section">
        <div className="container contact-layout">
          <div>
            <p className="eyebrow">
              <span />
              {t([
                "HERE TO HELP YOU GROW",
                "ПОМОГАЕМ ВАМ РАСТИ",
                "RIVOJLANISHINGIZGA YORDAM",
              ])}
            </p>
            <h2>
              {t([
                "Say hello to what’s next.",
                "Скажите hello новому.",
                "Yangilikka hello deng.",
              ])}
            </h2>
            <p>
              {t([
                "Our fictional admissions team would help you find the right programme, branch, and schedule.",
                "Наша вымышленная приёмная команда помогла бы выбрать программу, филиал и расписание.",
                "Xayoliy qabul jamoamiz dastur, filial va jadvalni tanlashga yordam berardi.",
              ])}
            </p>
            <div className="contact-info">
              <div>
                <Phone size={22} />
                <span>
                  <strong>+998 (00) 000-00-00</strong>
                  <small>
                    {t([
                      "Sample number · not connected",
                      "Пример номера · не подключён",
                      "Namuna raqam · ulanmagan",
                    ])}
                  </small>
                </span>
              </div>
              <div>
                <Mail size={22} />
                <span>
                  <strong>hello@imperial.example</strong>
                  <small>
                    {t([
                      "Reserved demo domain · no mailbox",
                      "Демо-домен · почта не подключена",
                      "Namuna domen · pochta ulanmagan",
                    ])}
                  </small>
                </span>
              </div>
              <div>
                <Clock3 size={22} />
                <span>
                  <strong>
                    {t([
                      "Monday–Saturday · 08:00–21:00",
                      "Понедельник–суббота · 08:00–21:00",
                      "Dushanba–shanba · 08:00–21:00",
                    ])}
                  </strong>
                  <small>
                    {t([
                      "Illustrative opening hours · Tashkent time",
                      "Пример часов работы · время Ташкента",
                      "Namuna ish vaqti · Toshkent vaqti",
                    ])}
                  </small>
                </span>
              </div>
            </div>
            <div className="contact-social">
              <a href="https://t.me/" target="_blank" rel="noreferrer">
                <Send size={17} />
                Telegram
                <ArrowUpRight size={15} />
              </a>
              <a href="https://instagram.com/" target="_blank" rel="noreferrer">
                <Instagram size={17} />
                Instagram
                <ArrowUpRight size={15} />
              </a>
            </div>
            <p className="demo-note">
              {t([
                "Social links open the platforms, not real academy accounts.",
                "Ссылки ведут на платформы, а не аккаунты академии.",
                "Havolalar haqiqiy akademiya hisoblariga emas, platformalarga olib boradi.",
              ])}
            </p>
            <MapPlaceholder />
          </div>
          <div className="contact-form-card">
            <h3>
              {t([
                "Tell us a little about yourself.",
                "Расскажите немного о себе.",
                "O‘zingiz haqingizda ayting.",
              ])}
            </h3>
            <RegistrationForm contact onSuccess={onSuccess} />
          </div>
        </div>
      </section>
    </>
  );
}
export function TrialPage({ onSuccess }: { onSuccess: () => void }) {
  const { t } = useLanguage();
  return (
    <>
      <PageHero
        eyebrow={t([
          "YOUR FIRST STEP",
          "ВАШ ПЕРВЫЙ ШАГ",
          "BIRINCHI QADAMINGIZ",
        ])}
        title={t([
          "Come curious. Leave inspired.",
          "Приходите с любопытством. Уходите с вдохновением.",
          "Qiziqish bilan keling. Ilhom bilan keting.",
        ])}
        text={t([
          "Explore a sample first-lesson registration. No booking is made and no personal information leaves your browser.",
          "Попробуйте регистрацию на пробный урок. Бронирование не создаётся, личные данные не покидают браузер.",
          "Birinchi dars uchun namuna ro‘yxatdan o‘tish. Dars band qilinmaydi, shaxsiy ma’lumot brauzeringizdan chiqmaydi.",
        ])}
      />
      <section className="section">
        <div className="container standalone-form">
          <RegistrationForm onSuccess={onSuccess} />
        </div>
      </section>
    </>
  );
}
export function PrivacyPage() {
  const { t } = useLanguage();
  return (
    <>
      <PageHero
        eyebrow="IMPERIAL ENGLISH ACADEMY"
        title={t([
          "A transparent demonstration.",
          "Прозрачная демонстрация.",
          "Ochiq namoyish.",
        ])}
        text={t(words.demo)}
      />
      <section className="section">
        <div className="container prose">
          <h2>
            {t(["About this website", "Об этом сайте", "Ushbu sayt haqida"])}
          </h2>
          <p>{t(words.demoPeople)}</p>
          <p>
            {t([
              "Imperial English Academy is a fictional frontend concept. It is not an operating school. Course prices, programmes, statistics, branches, hours, and contact details are examples. No accreditation, affiliation, score, or placement is guaranteed.",
              "Imperial English Academy — вымышленный фронтенд-проект, а не действующая школа. Цены, программы, статистика, филиалы, часы и контакты приведены для примера. Аккредитация, партнёрства, баллы и поступление не гарантируются.",
              "Imperial English Academy xayoliy frontend loyiha, amaldagi maktab emas. Narxlar, dasturlar, statistika, filiallar, ish vaqti va kontaktlar namuna. Akkreditatsiya, hamkorlik, ball yoki qabul kafolatlanmaydi.",
            ])}
          </p>
          <h3>
            {t(["Your form data", "Данные форм", "Shakl ma’lumotlaringiz"])}
          </h3>
          <p>{t(words.formDemo)}</p>
          <p>
            {t([
              "Forms validate in your browser and retain values only in temporary component state. Your chosen language is stored locally on this device. There is no analytics or tracking code in the application.",
              "Формы проверяются в браузере, значения хранятся только временно в состоянии компонента. Выбранный язык сохраняется на устройстве. В приложении нет кода аналитики или отслеживания.",
              "Shakllar brauzerda tekshiriladi va qiymatlar faqat vaqtinchalik komponent holatida saqlanadi. Tanlangan til qurilmada saqlanadi. Ilovada analitika yoki kuzatish kodi yo‘q.",
            ])}
          </p>
          <h3>
            {t([
              "Photography and external links",
              "Фото и внешние ссылки",
              "Suratlar va tashqi havolalar",
            ])}
          </h3>
          <p>
            {t([
              "Photography is illustrative stock imagery from Unsplash, not actual teachers, students, or campuses. External social and district-map links are clearly identified and open third-party websites with their own privacy policies.",
              "Фотографии Unsplash — иллюстрации, а не реальные учителя, студенты или филиалы. Внешние ссылки соцсетей и карт районов обозначены и ведут на сайты с собственными правилами конфиденциальности.",
              "Unsplash suratlari tasviriy, haqiqiy ustoz, talaba yoki filial emas. Ijtimoiy tarmoq va tuman xaritalari tashqi saytlarni o‘z maxfiylik siyosati bilan ochadi.",
            ])}
          </p>
        </div>
      </section>
    </>
  );
}
export function NotFound() {
  const { t } = useLanguage();
  return (
    <section className="section not-found container">
      <p className="eyebrow">404 / IMPERIAL</p>
      <h1>{t(words.notfound)}</h1>
      <Link to="/" className="button navy">
        {t(words.home)}
        <ArrowRight size={18} />
      </Link>
    </section>
  );
}
