import { useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  ArrowUpRight,
  Star,
  GraduationCap,
  UsersRound,
  BookOpen,
  BadgeCheck,
  Globe2,
  HeartHandshake,
  Plus,
  Minus,
  MoveDown,
  Quote,
  Check,
  MapPin,
} from "lucide-react";
import { courses, teachers, students, faq } from "../data";
import type { Teacher } from "../data";
import { useLanguage, words } from "../i18n";
import {
  ArrowLink,
  SectionHeading,
  Reveal,
  Counter,
  DemoNote,
  CTA,
} from "../components/ui";
import { CourseCard, TeacherCard } from "../components/Cards";
export function Statistics() {
  const { t } = useLanguage();
  return (
    <section className="statistics">
      <div className="container">
        <div className="stats-grid">
          {[
            {
              value: 2500,
              suffix: "+",
              label: [
                "Learners. Limitless potential.",
                "Студенты. Безграничный потенциал.",
                "O‘quvchilar. Cheksiz salohiyat.",
              ] as const,
            },
            {
              value: 35,
              suffix: "+",
              label: [
                "Teachers who care.",
                "Преподаватели, которым не всё равно.",
                "G‘amxo‘r ustozlar.",
              ] as const,
            },
            {
              value: 8.5,
              suffix: "",
              decimal: 1,
              label: [
                "An ambition worth pursuing.",
                "Цель, к которой стоит стремиться.",
                "Intilishga arziydigan maqsad.",
              ] as const,
            },
            {
              value: 3,
              suffix: "",
              label: [
                "Spaces to call your own.",
                "Места, где вы как дома.",
                "O‘zingizni uydagidek his qiling.",
              ] as const,
            },
          ].map((s, i) => (
            <div className="stat" key={i}>
              <strong>
                <Counter
                  value={s.value}
                  suffix={s.suffix}
                  decimals={s.decimal}
                />
                {i === 2 && <small>IELTS</small>}
              </strong>
              <span>{t(s.label)}</span>
            </div>
          ))}
        </div>
        <p className="stats-demo">
          {t([
            "Illustrative academy figures and target scores · demonstration only",
            "Пример показателей академии и целевых баллов · демо",
            "Akademiya ko‘rsatkichlari va maqsadli ballar · faqat namuna",
          ])}
        </p>
      </div>
    </section>
  );
}
export function FAQ() {
  const { t } = useLanguage();
  const [active, setActive] = useState<number | null>(0);
  return (
    <section className="section faq-section">
      <div className="container faq-layout">
        <div>
          <p className="eyebrow">
            <span />
            {t(["GOOD QUESTIONS", "ХОРОШИЕ ВОПРОСЫ", "YAXSHI SAVOLLAR"])}
          </p>
          <h2>{t(words.faq)}</h2>
          <p>
            {t([
              "Everything you need to take your first step. Still curious? We’re here for you.",
              "Всё для вашего первого шага. Остались вопросы? Мы рядом.",
              "Birinchi qadam uchun kerakli javoblar. Yana savollar bormi? Biz yordam beramiz.",
            ])}
          </p>
          <ArrowLink to="/contact">{t(words.contact)}</ArrowLink>
        </div>
        <div className="faq-list">
          {faq.map((f, i) => (
            <div
              className={`faq-item ${active === i ? "is-open" : ""}`}
              key={i}
            >
              <h3>
                <button
                  onClick={() => setActive(active === i ? null : i)}
                  aria-expanded={active === i}
                  aria-controls={`faq-answer-${i}`}
                >
                  <span className="faq-number">0{i + 1}</span>
                  <span>{t(f.q)}</span>
                  {active === i ? <Minus size={18} /> : <Plus size={18} />}
                </button>
              </h3>
              <div id={`faq-answer-${i}`} hidden={active !== i}>
                <p>{t(f.a)}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
export function ResultsSection({ full = false }: { full?: boolean }) {
  const { t } = useLanguage();
  return (
    <section
      className={`section results-section ${full ? "full-results" : ""}`}
    >
      <div className="container">
        <SectionHeading
          light
          eyebrow={t([
            "AMBITION, IN ACTION",
            "АМБИЦИИ В ДЕЙСТВИИ",
            "AMALDAGI MAQSADLAR",
          ])}
          title={t([
            "Big dreams. Brilliant next chapters.",
            "Большие мечты. Яркое продолжение.",
            "Katta orzular. Yorqin kelajak.",
          ])}
          text={t([
            "Every journey is personal. Here’s what progress could look like.",
            "Каждый путь уникален. Вот как может выглядеть прогресс.",
            "Har bir yo‘l o‘ziga xos. Rivojlanish shunday ko‘rinishi mumkin.",
          ])}
        >
          {!full && (
            <ArrowLink to="/results">
              {t([
                "Explore success stories",
                "Истории успеха",
                "Muvaffaqiyat hikoyalari",
              ])}
            </ArrowLink>
          )}
        </SectionHeading>
        <div className="results-grid">
          {students.map((s, i) => (
            <Reveal key={s.name} delay={i * 0.1} className="result-card">
              <div className="result-top">
                <span className="result-score">
                  <Counter value={s.score} decimals={1} />
                </span>
                <div>
                  <span>IELTS</span>
                  <small>
                    {t(["OVERALL BAND", "ОБЩИЙ БАЛЛ", "UMUMIY BALL"])}
                  </small>
                </div>
                <GraduationCap size={33} />
              </div>
              <div className="result-person">
                <img
                  src={`/images/${s.image}.jpg`}
                  alt={s.name}
                  loading="lazy"
                />
                <div>
                  <h3>{s.name}</h3>
                  <p>{t(s.goal)}</p>
                </div>
              </div>
              {full && (
                <>
                  <div className="skill-grid">
                    {s.skills.map((v, j) => (
                      <span key={j}>
                        {t(
                          [
                            ["Listening", "Аудирование", "Tinglash"],
                            ["Reading", "Чтение", "O‘qish"],
                            ["Writing", "Письмо", "Yozish"],
                            ["Speaking", "Говорение", "Gapirish"],
                          ][j] as [string, string, string],
                        )}
                        <b>{v.toFixed(1)}</b>
                      </span>
                    ))}
                  </div>
                  <p className="result-journey">
                    {t([
                      "Starting band",
                      "Начальный балл",
                      "Boshlang‘ich ball",
                    ])}
                    : {s.start} <ArrowRight size={14} /> {s.score.toFixed(1)}
                  </p>
                </>
              )}
              <p className="result-quote">“{t(s.quote)}”</p>
              <span className="sample-pill">
                {t([
                  "Illustrative success story",
                  "Вымышленная история успеха",
                  "Namuna muvaffaqiyat hikoyasi",
                ])}
              </span>
            </Reveal>
          ))}
        </div>
        <DemoNote />
      </div>
    </section>
  );
}
export default function Home({
  onTrial,
  onProfile,
}: {
  onTrial: () => void;
  onProfile: (t: Teacher) => void;
}) {
  const { t } = useLanguage();
  return (
    <>
      <section className="home-hero">
        <img
          className="hero-photo"
          src="/images/hero.jpg"
          alt={t([
            "Students collaborating around a table",
            "Студенты занимаются вместе",
            "Birgalikda o‘qiyotgan talabalar",
          ])}
          fetchPriority="high"
        />
        <div className="hero-shade" />
        <div className="hero-grid-pattern" />
        <div className="container hero-content">
          <div className="hero-copy">
            <p className="eyebrow">
              <span />
              {t([
                "A HIGHER STANDARD OF ENGLISH",
                "НОВЫЙ УРОВЕНЬ АНГЛИЙСКОГО",
                "INGLIZ TILINING YANGI DARAJASI",
              ])}
            </p>
            <h1>
              {t([
                "Your English.",
                "Ваш английский.",
                "Sizning ingliz tilingiz.",
              ])}
              <br />
              <span>
                {t(["Your Future.", "Ваше будущее.", "Sizning kelajagingiz."])}
              </span>
            </h1>
            <p className="hero-description">
              {t([
                "More than a language. A world of possibilities. Build your confidence, find your people, and go further with Imperial English Academy.",
                "Больше, чем язык. Целый мир возможностей. Обретите уверенность, найдите своих людей и двигайтесь дальше с Imperial English Academy.",
                "Bu shunchaki til emas. Bu imkoniyatlar dunyosi. Imperial English Academy bilan ishonch toping, do‘stlar orttiring va olg‘a intiling.",
              ])}
            </p>
            <div className="hero-buttons">
              <Link className="button gold" to="/courses">
                {t(words.explore)}
                <ArrowUpRight size={19} />
              </Link>
              <button className="button outline-light" onClick={onTrial}>
                {t(words.trial)}
                <ArrowRight size={18} />
              </button>
            </div>
            <div className="hero-trust">
              <div className="avatar-stack">
                {["teacher1", "teacher2", "teacher3", "teacher8"].map((img) => (
                  <img key={img} src={`/images/${img}.jpg`} alt="" />
                ))}
              </div>
              <div>
                <div className="stars">
                  {[1, 2, 3, 4, 5].map((n) => (
                    <Star key={n} size={11} fill="currentColor" />
                  ))}
                </div>
                <span>
                  {t([
                    "Small classes. Big possibilities.",
                    "Маленькие группы. Большие возможности.",
                    "Kichik guruhlar. Katta imkoniyatlar.",
                  ])}
                </span>
              </div>
            </div>
          </div>
          <div className="hero-note">
            <span className="hero-note-icon">
              <GraduationCap size={28} />
            </span>
            <div>
              <strong>
                {t([
                  "Your potential, unlocked.",
                  "Раскройте свой потенциал.",
                  "Salohiyatingizni oching.",
                ])}
              </strong>
              <p>
                {t([
                  "A little courage. A brighter tomorrow.",
                  "Немного смелости. Яркое завтра.",
                  "Biroz jasorat. Yorqin kelajak.",
                ])}
              </p>
            </div>
            <ArrowUpRight size={18} />
          </div>
          <div className="hero-bottom">
            <span>
              <MapPin size={14} />
              {t([
                "ROOTED IN TASHKENT. READY FOR THE WORLD.",
                "ИЗ ТАШКЕНТА — В БОЛЬШОЙ МИР.",
                "TOSHKENTDAN BUTUN DUNYOGA.",
              ])}
            </span>
            <a
              href="#courses"
              aria-label={t([
                "Scroll to courses",
                "Перейти к курсам",
                "Kurslarga o‘tish",
              ])}
            >
              <span>
                {t([
                  "DISCOVER IMPERIAL",
                  "ОТКРОЙТЕ IMPERIAL",
                  "IMPERIAL’NI KASHF ETING",
                ])}
              </span>
              <MoveDown size={16} />
            </a>
          </div>
        </div>
      </section>
      <Statistics />
      <section className="section courses-section" id="courses">
        <div className="container">
          <SectionHeading
            eyebrow={t([
              "FIND YOUR WAY FORWARD",
              "ВАШ ПУТЬ ВПЕРЁД",
              "OLG‘A YO‘LINGIZNI TOPING",
            ])}
            title={t([
              "Different goals. The right course.",
              "Разные цели. Подходящий курс.",
              "Turli maqsadlar. Mos kurslar.",
            ])}
            text={t([
              "From your first hello to your next big opportunity. There’s a place for you here.",
              "От первого hello до новых возможностей. Здесь есть место для вас.",
              "Ilk hello’dan yangi imkoniyatlargacha. Bu yerda siz uchun joy bor.",
            ])}
          >
            <ArrowLink to="/courses">{t(words.allCourses)}</ArrowLink>
          </SectionHeading>
          <div className="course-grid">
            {courses.slice(0, 3).map((c, i) => (
              <Reveal key={c.id} delay={i * 0.1}>
                <CourseCard course={c} index={i} />
              </Reveal>
            ))}
          </div>
          <div className="courses-bottom">
            <span>
              {t([
                "Not sure where to start? Let’s find your level together.",
                "Не знаете, с чего начать? Давайте определим ваш уровень.",
                "Qayerdan boshlashni bilmaysizmi? Darajangizni birga aniqlaymiz.",
              ])}
            </span>
            <button className="text-button" onClick={onTrial}>
              {t(["Find my course", "Подобрать курс", "Menga mos kurs"])}
              <ArrowRight size={16} />
            </button>
          </div>
        </div>
      </section>
      <section className="section why-section">
        <div className="container why-layout">
          <Reveal className="why-visual">
            <img
              src="/images/classroom.jpg"
              alt={t([
                "An inspiring learning environment",
                "Вдохновляющая учебная среда",
                "Ilhomlantiruvchi o‘quv muhiti",
              ])}
              loading="lazy"
            />
            <div className="why-image-caption">
              <span>
                <BookOpen size={23} />
              </span>
              <p>
                {t([
                  "A place to belong.",
                  "Ваше место.",
                  "Sizning makoningiz.",
                ])}
                <small>
                  {t([
                    "And room to become more.",
                    "И пространство для роста.",
                    "Rivojlanish uchun keng imkoniyat.",
                  ])}
                </small>
              </p>
            </div>
            <span className="vertical-label">THE IMPERIAL EXPERIENCE</span>
          </Reveal>
          <Reveal className="why-copy">
            <p className="eyebrow">
              <span />
              {t([
                "THE IMPERIAL DIFFERENCE",
                "ПРЕИМУЩЕСТВА IMPERIAL",
                "IMPERIAL FARQI",
              ])}
            </p>
            <h2>
              {t([
                "Good English changes things. Great teaching changes you.",
                "Английский меняет многое. Хороший учитель меняет вас.",
                "Yaxshi ingliz tili hayotni. Yaxshi ustoz sizni o‘zgartiradi.",
              ])}
            </h2>
            <p>
              {t([
                "We bring thoughtful teaching, a supportive community, and a clear sense of direction to every lesson. Because your goals deserve more than a textbook.",
                "В каждом уроке — продуманное обучение, поддержка сообщества и ясное направление. Ведь ваши цели заслуживают большего, чем учебник.",
                "Har bir darsda puxta ta’lim, do‘stona hamjamiyat va aniq yo‘nalish. Chunki maqsadlaringiz darslikdan ko‘proq narsaga loyiq.",
              ])}
            </p>
            <div className="advantages">
              {[
                {
                  icon: BadgeCheck,
                  title: [
                    "Teachers who see your potential",
                    "Учителя, которые видят ваш потенциал",
                    "Salohiyatingizni ko‘radigan ustozlar",
                  ] as const,
                  text: [
                    "Expert guidance. Personal attention. Genuine encouragement.",
                    "Опыт, индивидуальное внимание и искренняя поддержка.",
                    "Tajribali yo‘l-yo‘riq, shaxsiy e’tibor va samimiy yordam.",
                  ] as const,
                },
                {
                  icon: UsersRound,
                  title: [
                    "Small groups. Stronger connections.",
                    "Небольшие группы. Крепкие связи.",
                    "Kichik guruhlar. Mustahkam aloqalar.",
                  ] as const,
                  text: [
                    "More time to speak, ask, and make yourself heard.",
                    "Больше времени говорить, спрашивать и быть услышанным.",
                    "Gapirish, so‘rash va fikr bildirish uchun ko‘proq vaqt.",
                  ] as const,
                },
                {
                  icon: Globe2,
                  title: [
                    "English for the world outside",
                    "Английский для реального мира",
                    "Haqiqiy dunyo uchun ingliz tili",
                  ] as const,
                  text: [
                    "Real conversations, useful skills, lasting confidence.",
                    "Живые разговоры, полезные навыки, уверенность надолго.",
                    "Jonli suhbatlar, foydali ko‘nikmalar va mustahkam ishonch.",
                  ] as const,
                },
              ].map(({ icon: Icon, title, text }) => (
                <div className="advantage" key={title[0]}>
                  <span>
                    <Icon size={20} />
                  </span>
                  <div>
                    <h3>{t(title)}</h3>
                    <p>{t(text)}</p>
                  </div>
                </div>
              ))}
            </div>
            <ArrowLink to="/about">{t(words.learn)}</ArrowLink>
          </Reveal>
        </div>
      </section>
      <section className="section">
        <div className="container">
          <SectionHeading
            eyebrow={t([
              "GOOD PEOPLE. GREAT TEACHERS.",
              "ХОРОШИЕ ЛЮДИ. ОТЛИЧНЫЕ УЧИТЕЛЯ.",
              "YAXSHI INSONLAR. AJOYIB USTOZLAR.",
            ])}
            title={t([
              "Meet your next biggest supporters.",
              "Ваши будущие наставники.",
              "Bo‘lajak ustozlaringiz bilan tanishing.",
            ])}
            text={t([
              "Expertise is a given. Passion makes the difference.",
              "Опыт — это основа. Увлечённость меняет всё.",
              "Tajriba — poydevor. Ishtiyoq esa hammasini o‘zgartiradi.",
            ])}
          >
            <ArrowLink to="/teachers">{t(words.allTeachers)}</ArrowLink>
          </SectionHeading>
          <div className="teacher-grid">
            {teachers.slice(0, 4).map((teacher, i) => (
              <Reveal key={teacher.id} delay={i * 0.08}>
                <TeacherCard teacher={teacher} onProfile={onProfile} />
              </Reveal>
            ))}
          </div>
          <DemoNote />
        </div>
      </section>
      <ResultsSection />
      <section className="section testimonials-section">
        <div className="container">
          <SectionHeading
            eyebrow={t([
              "THE WORD AROUND IMPERIAL",
              "ЧТО ГОВОРЯТ ОБ IMPERIAL",
              "IMPERIAL HAQIDAGI FIKRLAR",
            ])}
            title={t(words.testimonials)}
          >
            <span className="testimonial-mark">
              <HeartHandshake size={25} />
              {t([
                "A community that grows together",
                "Сообщество, которое растёт вместе",
                "Birga rivojlanadigan hamjamiyat",
              ])}
            </span>
          </SectionHeading>
          <div className="testimonial-grid">
            {students.slice(0, 2).map((s) => (
              <article className="testimonial" key={s.name}>
                <div className="testimonial-stars">
                  <div className="stars">
                    {[1, 2, 3, 4, 5].map((n) => (
                      <Star key={n} size={14} fill="currentColor" />
                    ))}
                  </div>
                  <Quote size={28} />
                </div>
                <blockquote>“{t(s.quote)}”</blockquote>
                <div className="testimonial-person">
                  <img src={`/images/${s.image}.jpg`} alt="" loading="lazy" />
                  <div>
                    <strong>{s.name}</strong>
                    <small>
                      {t([
                        "IELTS programme · fictional student",
                        "Курс IELTS · вымышленный студент",
                        "IELTS kursi · xayoliy talaba",
                      ])}
                    </small>
                  </div>
                  <Check size={16} />
                </div>
              </article>
            ))}
          </div>
          <DemoNote />
        </div>
      </section>
      <section className="gallery-teaser">
        <div className="container">
          <div className="gallery-intro">
            <div>
              <p className="eyebrow">
                <span />
                {t(["LIFE AT IMPERIAL", "ЖИЗНЬ В IMPERIAL", "IMPERIAL HAYOTI"])}
              </p>
              <h2>
                {t([
                  "More than lessons. A little more life.",
                  "Больше, чем уроки. Больше жизни.",
                  "Darslardan ko‘proq. Hayotga yaqinroq.",
                ])}
              </h2>
            </div>
            <ArrowLink to="/gallery">
              {t([
                "Step inside",
                "Загляните внутрь",
                "Ichkariga nazar tashlang",
              ])}
            </ArrowLink>
          </div>
          <div className="gallery-teaser-grid">
            {["hero", "club", "classroom"].map((image, i) => (
              <Link key={image} to="/gallery" aria-label={t(words.gallery)}>
                <img
                  src={`/images/${image}.jpg`}
                  loading="lazy"
                  alt={t(
                    [
                      [
                        "Learning together",
                        "Учимся вместе",
                        "Birgalikda o‘rganish",
                      ],
                      [
                        "Our community",
                        "Наше сообщество",
                        "Bizning hamjamiyat",
                      ],
                      [
                        "Inspiring spaces",
                        "Вдохновляющие пространства",
                        "Ilhomlantiruvchi makonlar",
                      ],
                    ][i] as [string, string, string],
                  )}
                />
                <span>
                  <ArrowUpRight size={23} />
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>
      <FAQ />
      <CTA onTrial={onTrial} />
    </>
  );
}
