import { useEffect, useState } from "react";
import { NavLink, Link, useLocation } from "react-router-dom";
import {
  ArrowRight,
  ArrowUp,
  MapPin,
  Menu,
  X,
  ArrowUpRight,
  Instagram,
  Send,
  Phone,
  Globe2,
} from "lucide-react";
import { useLanguage, words } from "../i18n";
import { Logo } from "./ui";
const nav = [
  ["about", "/about"],
  ["courses", "/courses"],
  ["teachers", "/teachers"],
  ["results", "/results"],
  ["branches", "/branches"],
] as const;
export function Header({ onTrial }: { onTrial: () => void }) {
  const { t, language, setLanguage } = useLanguage();
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  useEffect(() => {
    setOpen(false);
  }, [pathname]);
  useEffect(() => {
    if (!open) return;
    const esc = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("keydown", esc);
    return () => document.removeEventListener("keydown", esc);
  }, [open]);
  return (
    <>
      <div className="announcement">
        <div className="container announcement-inner">
          <span>
            <span className="live-dot" />
            {t([
              "A world of opportunities starts with English.",
              "Мир возможностей начинается с английского.",
              "Imkoniyatlar dunyosi ingliz tilidan boshlanadi.",
            ])}
          </span>
          <span className="announcement-location">
            <MapPin size={12} />
            {t([
              "Tashkent, Uzbekistan",
              "Ташкент, Узбекистан",
              "Toshkent, O‘zbekiston",
            ])}
          </span>
        </div>
      </div>
      <header className="header">
        <div className="container nav-inner">
          <Logo />
          <nav
            className="desktop-nav"
            aria-label={t([
              "Main navigation",
              "Главная навигация",
              "Asosiy menyu",
            ])}
          >
            {nav.map(([key, path]) => (
              <NavLink key={key} to={path}>
                {t(words[key])}
              </NavLink>
            ))}
          </nav>
          <div className="nav-actions">
            <div className="language-select">
              <Globe2 size={15} />
              <select
                aria-label="Language / Язык / Til"
                value={language}
                onChange={(e) =>
                  setLanguage(e.target.value as "en" | "ru" | "uz")
                }
              >
                <option value="en">EN</option>
                <option value="ru">RU</option>
                <option value="uz">UZ</option>
              </select>
            </div>
            <button className="button gold nav-trial" onClick={onTrial}>
              {t(words.trial)}
              <ArrowUpRight size={16} />
            </button>
            <button
              className="icon-button mobile-toggle"
              aria-label={t(["Toggle menu", "Открыть меню", "Menyuni ochish"])}
              aria-expanded={open}
              aria-controls="mobile-menu"
              onClick={() => setOpen(!open)}
            >
              {open ? <X /> : <Menu />}
            </button>
          </div>
        </div>
        {open && (
          <nav
            id="mobile-menu"
            className="mobile-menu"
            aria-label={t([
              "Mobile navigation",
              "Мобильная навигация",
              "Mobil menyu",
            ])}
          >
            {[
              ["home", "/"],
              ...nav,
              ["gallery", "/gallery"],
              ["contact", "/contact"],
            ].map(([key, path]) => (
              <NavLink key={key} to={path}>
                {t(words[key as keyof typeof words])}
                <ArrowUpRight size={17} />
              </NavLink>
            ))}
            <button
              className="button gold"
              onClick={() => {
                setOpen(false);
                onTrial();
              }}
            >
              {t(words.trial)}
              <ArrowRight size={18} />
            </button>
          </nav>
        )}
      </header>
    </>
  );
}
export function Footer({ onTrial }: { onTrial: () => void }) {
  const { t } = useLanguage();
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-top">
          <div className="footer-brand">
            <Logo light />
            <p>
              {t([
                "English opens doors. We help you walk through them. Discover a place to learn, connect, and become more.",
                "Английский открывает двери. Мы помогаем сделать первый шаг. Учитесь, общайтесь и становитесь лучше.",
                "Ingliz tili eshiklarni ochadi. Biz sizga ilk qadamda yordam beramiz. O‘rganing, muloqot qiling va rivojlaning.",
              ])}
            </p>
            <div className="socials">
              <a
                href="https://t.me/"
                target="_blank"
                rel="noreferrer"
                aria-label="Telegram — platform link, demo academy"
              >
                <Send size={18} />
              </a>
              <a
                href="https://www.instagram.com/"
                target="_blank"
                rel="noreferrer"
                aria-label="Instagram — platform link, demo academy"
              >
                <Instagram size={18} />
              </a>
              <span>
                {t([
                  "Demo social links",
                  "Демо-ссылки соцсетей",
                  "Namuna ijtimoiy havolalar",
                ])}
              </span>
            </div>
          </div>
          <div>
            <h4>
              {t([
                "Discover Imperial",
                "Откройте Imperial",
                "Imperial bilan tanishing",
              ])}
            </h4>
            {[
              ["about", "/about"],
              ["teachers", "/teachers"],
              ["results", "/results"],
              ["gallery", "/gallery"],
            ].map(([key, to]) => (
              <Link key={key} to={to}>
                {t(words[key as keyof typeof words])}
              </Link>
            ))}
          </div>
          <div>
            <h4>{t(words.courses)}</h4>
            {[
              "General English",
              "IELTS Preparation",
              "Kids English",
              "Online English",
            ].map((c, i) => (
              <Link
                key={c}
                to={`/courses/${["general-english", "ielts-preparation", "kids-english", "online-english"][i]}`}
              >
                {t(
                  [
                    [c, "Общий английский", "Umumiy ingliz tili"],
                    [c, "Подготовка к IELTS", "IELTS tayyorlov"],
                    [c, "Английский для детей", "Bolalar ingliz tili"],
                    [c, "Английский онлайн", "Onlayn ingliz tili"],
                  ][i] as [string, string, string],
                )}
              </Link>
            ))}
          </div>
          <div>
            <h4>{t(["Let’s connect", "Будем на связи", "Bog‘lanamiz"])}</h4>
            <Link to="/contact">
              <Phone size={14} /> +998 (00) 000-00-00
            </Link>
            <small>
              {t([
                "Sample number · not connected",
                "Пример номера · не подключён",
                "Namuna raqam · ulanmagan",
              ])}
            </small>
            <Link to="/branches">
              <MapPin size={14} />
              {t([
                "Tashkent, Uzbekistan",
                "Ташкент, Узбекистан",
                "Toshkent, O‘zbekiston",
              ])}
            </Link>
            <button className="footer-trial" onClick={onTrial}>
              {t(words.trial)}
              <ArrowUpRight size={17} />
            </button>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© 2026 Imperial English Academy.</span>
          <span>{t(words.demo)}</span>
          <Link to="/privacy">
            {t([
              "Demo & privacy notice",
              "Демо и конфиденциальность",
              "Namuna va maxfiylik",
            ])}
            <ArrowUpRight size={12} />
          </Link>
        </div>
      </div>
    </footer>
  );
}
export function ScrollTop() {
  const [show, setShow] = useState(false);
  const { t } = useLanguage();
  useEffect(() => {
    const update = () => setShow(window.scrollY > 650);
    window.addEventListener("scroll", update, { passive: true });
    return () => window.removeEventListener("scroll", update);
  }, []);
  return show ? (
    <button
      className="scroll-top"
      aria-label={t(["Back to top", "Наверх", "Yuqoriga"])}
      onClick={() =>
        window.scrollTo({
          top: 0,
          behavior: window.matchMedia("(prefers-reduced-motion: reduce)")
            .matches
            ? "instant"
            : "smooth",
        })
      }
    >
      <ArrowUp size={20} />
    </button>
  ) : null;
}
