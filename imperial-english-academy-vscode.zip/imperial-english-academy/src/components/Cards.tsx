import { Clock3, ArrowUpRight, ArrowRight, GraduationCap } from "lucide-react";
import { Link } from "react-router-dom";
import { useLanguage, words } from "../i18n";
import type { Course, Teacher } from "../data";
export function CourseCard({
  course,
  index = 0,
}: {
  course: Course;
  index?: number;
}) {
  const { t } = useLanguage();
  return (
    <article
      className={`course-card ${course.id === "ielts-preparation" ? "featured" : ""}`}
    >
      <Link
        className="course-image"
        to={`/courses/${course.id}`}
        aria-label={t(course.title)}
      >
        <img
          src={`/images/${course.image}.jpg`}
          alt={t(course.title)}
          loading="lazy"
        />
        <span className="image-tag">{course.level}</span>
        <span className="course-number">0{index + 1}</span>
      </Link>
      <div className="course-body">
        <p className="eyebrow">{t(course.tag)}</p>
        <h3>
          <Link to={`/courses/${course.id}`}>{t(course.title)}</Link>
          <ArrowUpRight size={24} />
        </h3>
        <p>{t(course.description)}</p>
        <div className="course-meta">
          <span>
            <Clock3 size={15} />
            {t(course.duration)}
          </span>
          <span>
            <GraduationCap size={16} />
            {t(words.group)}
          </span>
        </div>
        <Link className="course-link" to={`/courses/${course.id}`}>
          {t(words.details)}
          <ArrowRight size={17} />
        </Link>
      </div>
    </article>
  );
}
export function TeacherCard({
  teacher,
  onProfile,
}: {
  teacher: Teacher;
  onProfile: (t: Teacher) => void;
}) {
  const { t } = useLanguage();
  return (
    <article className="teacher-card">
      <button
        className="teacher-image"
        onClick={() => onProfile(teacher)}
        aria-label={`${t(words.profile)}: ${teacher.name}`}
      >
        <img
          src={`/images/${teacher.image}.jpg`}
          alt={teacher.name}
          loading="lazy"
        />
        {teacher.score && (
          <span className="score-badge">
            IELTS <b>{teacher.score}</b>
          </span>
        )}
        <span className="teacher-hover">
          {t(words.profile)}
          <ArrowUpRight size={18} />
        </span>
      </button>
      <div className="teacher-body">
        <p>{t(teacher.role)}</p>
        <h3>{teacher.name}</h3>
        <span>
          {teacher.years} {t(words.years)}
        </span>
        <small>{teacher.qualification}</small>
        <button className="text-button" onClick={() => onProfile(teacher)}>
          {t(words.profile)}
          <ArrowRight size={16} />
        </button>
      </div>
    </article>
  );
}
