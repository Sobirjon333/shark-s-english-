import { useEffect, useRef, useState } from "react";
import { ArrowRight, Check, LoaderCircle, ShieldCheck } from "lucide-react";
import { useLanguage, words } from "../i18n";
import { branches, courses } from "../data";
type Props = {
  contact?: boolean;
  initialCourse?: string;
  onSuccess?: () => void;
};
export default function RegistrationForm({
  contact = false,
  initialCourse = "",
  onSuccess,
}: Props) {
  const { t } = useLanguage();
  const [values, setValues] = useState({
    name: "",
    phone: "+998 ",
    course: initialCourse,
    branch: "",
    time: "",
    message: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const formRef = useRef<HTMLFormElement>(null);
  useEffect(
    () => () => {
      if (timer.current) clearTimeout(timer.current);
    },
    [],
  );
  const update = (field: keyof typeof values, value: string) => {
    setValues((v) => ({ ...v, [field]: value }));
    setErrors((e) => ({ ...e, [field]: "" }));
  };
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const next: Record<string, string> = {};
    if (values.name.trim().length < 2)
      next.name = t([
        "Please enter at least two characters.",
        "Введите минимум два символа.",
        "Kamida ikki belgi kiriting.",
      ]);
    if (!/^998\d{9}$/.test(values.phone.replace(/\D/g, "")))
      next.phone = t([
        "Use +998 followed by 9 digits.",
        "Введите +998 и 9 цифр.",
        "+998 va 9 ta raqam kiriting.",
      ]);
    if (!values.course)
      next.course = t([
        "Please choose a course.",
        "Выберите курс.",
        "Kursni tanlang.",
      ]);
    if (!contact && !values.branch)
      next.branch = t([
        "Please choose a branch.",
        "Выберите филиал.",
        "Filialni tanlang.",
      ]);
    if (!contact && !values.time)
      next.time = t([
        "Please choose a time.",
        "Выберите время.",
        "Vaqtni tanlang.",
      ]);
    setErrors(next);
    if (Object.keys(next).length) {
      requestAnimationFrame(() =>
        formRef.current
          ?.querySelector<HTMLElement>('[aria-invalid="true"]')
          ?.focus(),
      );
      return;
    }
    setLoading(true);
    timer.current = setTimeout(() => {
      setLoading(false);
      setSuccess(true);
      onSuccess?.();
    }, 850);
  };
  if (success)
    return (
      <div className="form-success" role="status">
        <span className="success-icon">
          <Check size={32} />
        </span>
        <p className="eyebrow">IMPERIAL ENGLISH ACADEMY</p>
        <h2>{t(words.success)}</h2>
        <p>{t(words.successBody)}</p>
        <button
          className="button navy"
          onClick={() => {
            setSuccess(false);
            setValues({
              name: "",
              phone: "+998 ",
              course: "",
              branch: "",
              time: "",
              message: "",
            });
          }}
        >
          {t(["Try another demo", "Попробовать снова", "Yana sinab ko‘rish"])}
          <ArrowRight size={17} />
        </button>
      </div>
    );
  const error = (key: string) =>
    errors[key] ? (
      <span className="field-error" id={`error-${key}`}>
        {errors[key]}
      </span>
    ) : null;
  return (
    <form
      noValidate
      onSubmit={submit}
      ref={formRef}
      className="registration-form"
    >
      <div className="form-grid">
        <label className="field full">
          {t(words.name)}
          <input
            aria-label={t(words.name)}
            autoComplete="name"
            name="name"
            value={values.name}
            onChange={(e) => update("name", e.target.value)}
            placeholder={t(["Your name", "Ваше имя", "Ismingiz"])}
            aria-invalid={!!errors.name}
            aria-describedby={errors.name ? "error-name" : undefined}
            required
            maxLength={100}
          />
          {error("name")}
        </label>
        <label className="field full">
          {t(words.phone)}
          <input
            aria-label={t(words.phone)}
            type="tel"
            autoComplete="tel"
            name="phone"
            value={values.phone}
            onChange={(e) => update("phone", e.target.value)}
            aria-invalid={!!errors.phone}
            aria-describedby={errors.phone ? "error-phone" : undefined}
            required
            maxLength={22}
            inputMode="tel"
          />
          {error("phone")}
        </label>
        <label className="field full">
          {t(words.course)}
          <select
            aria-label={t(words.course)}
            value={values.course}
            onChange={(e) => update("course", e.target.value)}
            aria-invalid={!!errors.course}
            aria-describedby={errors.course ? "error-course" : undefined}
            required
          >
            <option value="">{t(words.select)}</option>
            {courses.map((c) => (
              <option key={c.id} value={c.id}>
                {t(c.title)}
              </option>
            ))}
          </select>
          {error("course")}
        </label>
        {!contact && (
          <>
            <label className="field">
              {t(words.branch)}
              <select
                aria-label={t(words.branch)}
                value={values.branch}
                onChange={(e) => update("branch", e.target.value)}
                aria-invalid={!!errors.branch}
                aria-describedby={errors.branch ? "error-branch" : undefined}
                required
              >
                <option value="">{t(words.select)}</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
                <option value="online">
                  {t(["Online", "Онлайн", "Onlayn"])}
                </option>
              </select>
              {error("branch")}
            </label>
            <label className="field">
              {t(words.time)}
              <select
                aria-label={t(words.time)}
                value={values.time}
                onChange={(e) => update("time", e.target.value)}
                aria-invalid={!!errors.time}
                aria-describedby={errors.time ? "error-time" : undefined}
                required
              >
                <option value="">{t(words.select)}</option>
                <option value="morning">
                  {t([
                    "Morning · 09:00–12:00",
                    "Утро · 09:00–12:00",
                    "Ertalab · 09:00–12:00",
                  ])}
                </option>
                <option value="afternoon">
                  {t([
                    "Afternoon · 13:00–17:00",
                    "День · 13:00–17:00",
                    "Kunduz · 13:00–17:00",
                  ])}
                </option>
                <option value="evening">
                  {t([
                    "Evening · 18:00–21:00",
                    "Вечер · 18:00–21:00",
                    "Kechqurun · 18:00–21:00",
                  ])}
                </option>
              </select>
              {error("time")}
            </label>
          </>
        )}
        {contact && (
          <label className="field full">
            {t(words.message)}{" "}
            <span className="muted">
              {t(["(optional)", "(необязательно)", "(ixtiyoriy)"])}
            </span>
            <textarea
              aria-label={t(words.message)}
              value={values.message}
              onChange={(e) => update("message", e.target.value)}
              rows={4}
              maxLength={2000}
              placeholder={t([
                "Tell us about your goals…",
                "Расскажите о своих целях…",
                "Maqsadlaringiz haqida yozing…",
              ])}
            />
          </label>
        )}
      </div>
      <button
        className="button navy form-submit"
        type="submit"
        disabled={loading}
      >
        {loading ? (
          <>
            <LoaderCircle className="spin" size={18} />
            {t(words.sending)}
          </>
        ) : (
          <>
            {t(words.submit)}
            <ArrowRight size={18} />
          </>
        )}
      </button>
      <p className="form-disclaimer">
        <ShieldCheck size={17} />
        {t(words.formDemo)}
      </p>
    </form>
  );
}
