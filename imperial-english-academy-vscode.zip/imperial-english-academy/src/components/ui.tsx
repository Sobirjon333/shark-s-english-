import { useEffect, useRef, useState } from "react";
import type { ReactNode } from "react";
import { motion, useInView, useReducedMotion } from "framer-motion";
import { ArrowUpRight, Crown, X, Check, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { useLanguage, words } from "../i18n";
export function Logo({ light = false }: { light?: boolean }) {
  return (
    <Link
      to="/"
      className={`logo ${light ? "logo-light" : ""}`}
      aria-label="Imperial English Academy home"
    >
      <span className="logo-mark">
        <Crown size={29} strokeWidth={1.35} />
        <span />
      </span>
      <span>
        <strong>IMPERIAL</strong>
        <small>ENGLISH ACADEMY</small>
      </span>
    </Link>
  );
}
export function ArrowLink({
  to,
  children,
  className = "",
}: {
  to: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <Link to={to} className={`arrow-link ${className}`}>
      {children}
      <ArrowUpRight size={18} />
    </Link>
  );
}
export function Reveal({
  children,
  className = "",
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  const reduced = useReducedMotion();
  return (
    <motion.div
      className={className}
      initial={reduced ? false : { opacity: 0, y: 22 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.12 }}
      transition={{ duration: 0.55, delay }}
    >
      {children}
    </motion.div>
  );
}
export function SectionHeading({
  eyebrow,
  title,
  text,
  children,
  light = false,
}: {
  eyebrow: string;
  title: string;
  text?: string;
  children?: ReactNode;
  light?: boolean;
}) {
  return (
    <div className={`section-heading ${light ? "light" : ""}`}>
      <div>
        <p className="eyebrow">
          <span />
          {eyebrow}
        </p>
        <h2>{title}</h2>
        {text && <p className="section-description">{text}</p>}
      </div>
      {children}
    </div>
  );
}
export function PageHero({
  eyebrow,
  title,
  text,
  image,
}: {
  eyebrow: string;
  title: string;
  text: string;
  image?: string;
}) {
  return (
    <section
      className={`page-hero ${image ? "with-image" : ""}`}
      style={
        image
          ? {
              backgroundImage: `linear-gradient(90deg,rgba(13,29,48,.95),rgba(13,29,48,.5)),url(/images/${image}.jpg)`,
            }
          : {}
      }
    >
      <div className="container">
        <p className="eyebrow">
          <span />
          {eyebrow}
        </p>
        <h1>{title}</h1>
        <p>{text}</p>
        <span className="hero-corner">IMPERIAL / TASHKENT</span>
      </div>
    </section>
  );
}
export function Counter({
  value,
  suffix = "",
  decimals = 0,
}: {
  value: number;
  suffix?: string;
  decimals?: number;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const visible = useInView(ref, { once: true });
  const [count, setCount] = useState(0);
  const reduced = useReducedMotion();
  useEffect(() => {
    if (!visible) return;
    if (reduced) {
      setCount(value);
      return;
    }
    const start = performance.now();
    let raf: number;
    const tick = (now: number) => {
      const p = Math.min((now - start) / 1400, 1);
      setCount(value * (1 - Math.pow(1 - p, 3)));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [visible, value, reduced]);
  return (
    <span ref={ref}>
      {count.toFixed(decimals)}
      {suffix}
    </span>
  );
}
export function Dialog({
  children,
  onClose,
  title,
  className = "",
}: {
  children: ReactNode;
  onClose: () => void;
  title: string;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const { t } = useLanguage();
  useEffect(() => {
    const previous = document.activeElement as HTMLElement;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    ref.current?.querySelector<HTMLElement>("button,input")?.focus();
    const listener = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "Tab") {
        const els = ref.current?.querySelectorAll<HTMLElement>(
          'button:not([disabled]),a[href],input,select,textarea,[tabindex="0"]',
        );
        if (!els?.length) return;
        const first = els[0],
          last = els[els.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", listener);
    return () => {
      document.body.style.overflow = overflow;
      document.removeEventListener("keydown", listener);
      previous?.focus();
    };
  }, [onClose]);
  return (
    <div
      className="modal-backdrop"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className={`dialog ${className}`}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        ref={ref}
      >
        <button
          className="dialog-close icon-button"
          onClick={onClose}
          aria-label={t(words.close)}
        >
          <X size={21} />
        </button>
        {children}
      </motion.div>
    </div>
  );
}
export function CheckList({ items }: { items: string[] }) {
  return (
    <ul className="check-list">
      {items.map((item) => (
        <li key={item}>
          <span>
            <Check size={14} />
          </span>
          {item}
        </li>
      ))}
    </ul>
  );
}
export function DemoNote() {
  const { t } = useLanguage();
  return <p className="demo-note">{t(words.demoPeople)}</p>;
}
export function CTA({ onTrial }: { onTrial: () => void }) {
  const { t } = useLanguage();
  return (
    <section className="cta-section">
      <div className="container cta-inner">
        <div>
          <p className="eyebrow">
            <span />
            {t([
              "A SMALL STEP. A WORLD OF POSSIBILITIES.",
              "МАЛЕНЬКИЙ ШАГ. МИР ВОЗМОЖНОСТЕЙ.",
              "KICHIK QADAM. CHEKSIZ IMKONIYATLAR.",
            ])}
          </p>
          <h2>
            {t([
              "Your next chapter starts here.",
              "Ваша новая глава начинается здесь.",
              "Yangi bosqichingiz shu yerda boshlanadi.",
            ])}
          </h2>
          <p>
            {t([
              "Meet your teacher. Find your level. Make yourself at home.",
              "Познакомьтесь с преподавателем. Узнайте свой уровень. Почувствуйте себя как дома.",
              "Ustozingiz bilan tanishing. Darajangizni biling. O‘zingizni uydagidek his qiling.",
            ])}
          </p>
        </div>
        <button className="button navy" onClick={onTrial}>
          {t(words.trial)}
          <ArrowRight size={18} />
        </button>
        <Crown className="cta-watermark" />
      </div>
    </section>
  );
}
