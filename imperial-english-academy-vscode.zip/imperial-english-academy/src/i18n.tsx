import { createContext, useContext, useState, useEffect } from "react";
import type { ReactNode } from "react";
export type Text = readonly [string, string, string];
export type Language = "en" | "ru" | "uz";
const languages: Language[] = ["en", "ru", "uz"];
const LanguageContext = createContext({
  language: "en" as Language,
  setLanguage: (_l: Language) => {},
  t: (v: Text) => v[0] as string,
});
export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem("imperial-language");
    return languages.includes(saved as Language) ? (saved as Language) : "en";
  });
  useEffect(() => {
    document.documentElement.lang = language;
    localStorage.setItem("imperial-language", language);
  }, [language]);
  return (
    <LanguageContext.Provider
      value={{
        language,
        setLanguage,
        t: (v) => v[languages.indexOf(language)],
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
}
export const useLanguage = () => useContext(LanguageContext);
export const words = {
  home: ["Home", "Главная", "Bosh sahifa"],
  about: ["About us", "О нас", "Biz haqimizda"],
  courses: ["Courses", "Курсы", "Kurslar"],
  teachers: ["Our teachers", "Преподаватели", "Ustozlarimiz"],
  results: ["Results", "Результаты", "Natijalar"],
  gallery: ["Gallery", "Галерея", "Galereya"],
  branches: ["Branches", "Филиалы", "Filiallar"],
  contact: ["Contact us", "Контакты", "Bog‘lanish"],
  trial: ["Book a free lesson", "Бесплатный урок", "Bepul darsga yozilish"],
  explore: ["Explore courses", "Выбрать курс", "Kurslarni ko‘rish"],
  allCourses: ["View all courses", "Все курсы", "Barcha kurslar"],
  allTeachers: ["Meet all teachers", "Все преподаватели", "Barcha ustozlar"],
  details: ["Explore course", "Подробнее о курсе", "Kurs haqida"],
  profile: ["View profile", "Смотреть профиль", "Profilni ko‘rish"],
  all: ["All", "Все", "Barchasi"],
  enroll: ["Enroll in this course", "Записаться на курс", "Kursga yozilish"],
  demo: [
    "Fictional academy · Demonstration website",
    "Вымышленная академия · Демонстрационный сайт",
    "Xayoliy akademiya · Namoyish sayti",
  ],
  demoPeople: [
    "Illustrative profiles and results. All people, qualifications, scores, and testimonials are fictional demonstration data. Photography is illustrative.",
    "Профили и результаты приведены для примера. Люди, квалификации, баллы и отзывы вымышлены. Фотографии иллюстративные.",
    "Profillar va natijalar namuna uchun. Shaxslar, malakalar, ballar va fikrlar xayoliy. Suratlar tasviriy maqsadda.",
  ],
  name: ["Full name", "Полное имя", "Ism va familiya"],
  phone: ["Phone number", "Номер телефона", "Telefon raqami"],
  course: ["Preferred course", "Желаемый курс", "Tanlangan kurs"],
  branch: ["Preferred branch", "Желаемый филиал", "Tanlangan filial"],
  time: ["Preferred lesson time", "Удобное время", "Qulay dars vaqti"],
  message: ["Your message", "Ваше сообщение", "Xabaringiz"],
  select: ["Please select", "Выберите", "Tanlang"],
  submit: [
    "Send demo request",
    "Отправить демо-заявку",
    "Namuna arizasini yuborish",
  ],
  sending: [
    "Checking your request…",
    "Проверяем заявку…",
    "Ariza tekshirilmoqda…",
  ],
  formDemo: [
    "This is a demo form. Your information is not stored or sent, and no booking is made.",
    "Это демо-форма. Данные не сохраняются и не отправляются. Бронирование не создаётся.",
    "Bu namuna shakli. Ma’lumotlar saqlanmaydi va yuborilmaydi. Dars band qilinmaydi.",
  ],
  success: [
    "You’re ready for your next chapter.",
    "Вы готовы к новому этапу.",
    "Yangi bosqichga tayyorsiz.",
  ],
  successBody: [
    "Demo request validated successfully. Nothing was sent or saved. In a live academy, an advisor would help arrange your first lesson.",
    "Демо-заявка успешно проверена. Ничего не отправлено и не сохранено. В действующей академии консультант помог бы выбрать первый урок.",
    "Namuna arizasi tekshirildi. Hech narsa yuborilmadi yoki saqlanmadi. Haqiqiy akademiyada maslahatchi birinchi darsni tanlashga yordam berardi.",
  ],
  close: ["Close", "Закрыть", "Yopish"],
  years: ["years of experience", "лет опыта", "yillik tajriba"],
  duration: ["Duration", "Продолжительность", "Davomiyligi"],
  level: ["Level", "Уровень", "Daraja"],
  schedule: ["Sample schedule", "Пример расписания", "Namuna jadvali"],
  outcomes: [
    "What you’ll achieve",
    "Чему вы научитесь",
    "Nimalarni o‘rganasiz",
  ],
  audience: ["Who it’s for", "Для кого", "Kimlar uchun"],
  faq: [
    "A little clarity. A confident start.",
    "Всё понятно. Уверенный старт.",
    "Aniq javoblar. Ishonchli boshlanish.",
  ],
  directions: ["Explore the district", "Посмотреть район", "Tumanni ko‘rish"],
  sample: [
    "Sample branch · unverified location",
    "Пример филиала · адрес не подтверждён",
    "Namuna filial · manzil tasdiqlanmagan",
  ],
  back: ["Back to courses", "Ко всем курсам", "Barcha kurslarga"],
  learn: ["Discover our story", "Наша история", "Bizning tariximiz"],
  find: [
    "Find your place at Imperial.",
    "Найдите своё место в Imperial.",
    "Imperial’da o‘z o‘rningizni toping.",
  ],
  minutes: ["90-minute lessons", "Уроки по 90 минут", "90 daqiqalik darslar"],
  group: ["Small groups", "Небольшие группы", "Kichik guruhlar"],
  tuition: ["Illustrative tuition", "Пример стоимости", "Namuna to‘lov"],
  month: [" / month", " / месяц", " / oy"],
  testimonials: [
    "Real ambition. Shared inspiration.",
    "Большие цели. Общее вдохновение.",
    "Katta maqsadlar. Birgalikdagi ilhom.",
  ],
  notfound: [
    "This chapter hasn’t been written.",
    "Эта страница ещё не написана.",
    "Bu sahifa hali yozilmagan.",
  ],
} satisfies Record<string, Text>;
