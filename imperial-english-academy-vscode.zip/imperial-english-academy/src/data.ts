import type { Text } from "./i18n";
export type Course = {
  id: string;
  title: Text;
  tag: Text;
  description: Text;
  audience: Text;
  duration: Text;
  level: string;
  price: string;
  image: string;
  category: "adults" | "kids" | "online";
  outcomes: Text[];
  schedule: Text;
};
export const courses: Course[] = [
  {
    id: "general-english",
    title: ["General English", "Общий английский", "Umumiy ingliz tili"],
    tag: ["YOUR NEXT CHAPTER", "НОВАЯ ГЛАВА", "YANGI BOSQICH"],
    description: [
      "Build a strong foundation. Find your voice in English, one conversation at a time.",
      "Надёжная база и уверенное общение на английском — шаг за шагом.",
      "Mustahkam poydevor yarating. Har bir suhbat bilan ingliz tilida erkinroq gapiring.",
    ],
    audience: [
      "Adults and teens aged 16+ who want confident everyday English.",
      "Взрослые и подростки от 16 лет для уверенного повседневного общения.",
      "Kundalik ingliz tilini o‘rganmoqchi bo‘lgan 16 yoshdan kattalar.",
    ],
    duration: ["3 months / level", "3 месяца / уровень", "3 oy / daraja"],
    level: "A1 – C1",
    price: "890,000",
    image: "general",
    category: "adults",
    outcomes: [
      [
        "Speak naturally in everyday situations",
        "Общайтесь в повседневных ситуациях",
        "Kundalik vaziyatlarda erkin gapiring",
      ],
      [
        "Develop listening, reading, and writing together",
        "Развивайте аудирование, чтение и письмо",
        "Tinglash, o‘qish va yozishni rivojlantiring",
      ],
      [
        "Track progress with a personal learning plan",
        "Следите за прогрессом по личному плану",
        "Shaxsiy reja bilan rivojlaning",
      ],
    ],
    schedule: [
      "Mon / Wed / Fri · 18:30–20:00",
      "Пн / Ср / Пт · 18:30–20:00",
      "Du / Chor / Ju · 18:30–20:00",
    ],
  },
  {
    id: "ielts-preparation",
    title: ["IELTS Preparation", "Подготовка к IELTS", "IELTS tayyorlov"],
    tag: [
      "BIG GOALS. HIGHER SCORES.",
      "БОЛЬШИЕ ЦЕЛИ. ВЫШЕ БАЛЛЫ.",
      "KATTA MAQSAD. YUQORI NATIJA.",
    ],
    description: [
      "Turn your ambition into a plan. Focused preparation for the score you’re working towards.",
      "Превратите амбиции в план. Целевая подготовка к желаемому баллу.",
      "Maqsadingizni rejaga aylantiring. Kerakli ball uchun puxta tayyorgarlik.",
    ],
    audience: [
      "University applicants and professionals with B1+ English.",
      "Абитуриенты и специалисты с английским от B1.",
      "Ingliz tili B1+ bo‘lgan abituriyentlar va mutaxassislar.",
    ],
    duration: ["3–6 months", "3–6 месяцев", "3–6 oy"],
    level: "B1 – C1",
    price: "1,090,000",
    image: "ielts",
    category: "adults",
    outcomes: [
      [
        "Practise all four IELTS skills with timed mock tests",
        "Практикуйте четыре навыка IELTS с пробными тестами",
        "To‘rtta IELTS ko‘nikmasini sinov testlari bilan mashq qiling",
      ],
      [
        "Receive detailed essay and speaking feedback",
        "Получайте обратную связь по письму и речи",
        "Insho va nutq bo‘yicha batafsil fikr oling",
      ],
      [
        "Build a realistic strategy for your target band",
        "Постройте стратегию для целевого балла",
        "Maqsadli ball uchun aniq strategiya tuzing",
      ],
    ],
    schedule: [
      "Tue / Thu / Sat · 17:00–18:30",
      "Вт / Чт / Сб · 17:00–18:30",
      "Se / Pay / Sha · 17:00–18:30",
    ],
  },
  {
    id: "kids-english",
    title: [
      "Kids English",
      "Английский для детей",
      "Bolalar uchun ingliz tili",
    ],
    tag: [
      "SMALL STEPS. BRIGHT FUTURES.",
      "МАЛЕНЬКИЕ ШАГИ. БОЛЬШОЕ БУДУЩЕЕ.",
      "KICHIK QADAM. YORQIN KELAJAK.",
    ],
    description: [
      "Big curiosity deserves a big world. Playful English for confident young learners.",
      "Любознательность открывает мир. Увлекательный английский для детей.",
      "Qiziquvchanlik katta dunyoni ochadi. Bolalar uchun qiziqarli ingliz tili.",
    ],
    audience: [
      "Curious children aged 7–12, from their very first words.",
      "Любознательные дети 7–12 лет, начиная с первых слов.",
      "7–12 yoshli qiziquvchan bolalar, ilk so‘zlardan boshlab.",
    ],
    duration: ["4 months / level", "4 месяца / уровень", "4 oy / daraja"],
    level: "Pre-A1 – A2",
    price: "690,000",
    image: "kids",
    category: "kids",
    outcomes: [
      [
        "Learn through stories, games, and creative projects",
        "Учитесь через истории, игры и творчество",
        "Hikoyalar, o‘yinlar va ijod orqali o‘rganing",
      ],
      [
        "Build confidence speaking in a friendly group",
        "Уверенно говорите в дружной группе",
        "Do‘stona guruhda ishonch bilan gapiring",
      ],
      [
        "Share progress with parents each month",
        "Обсуждайте прогресс с родителями ежемесячно",
        "Har oy ota-onalar bilan natijalarni baham ko‘ring",
      ],
    ],
    schedule: [
      "Tue / Thu / Sat · 15:00–16:00",
      "Вт / Чт / Сб · 15:00–16:00",
      "Se / Pay / Sha · 15:00–16:00",
    ],
  },
  {
    id: "speaking-club",
    title: ["Speaking Club", "Разговорный клуб", "Suhbat klubi"],
    tag: ["FIND YOUR VOICE", "ОБРЕТИТЕ СВОЙ ГОЛОС", "OVOZINGIZNI TOPING"],
    description: [
      "Good conversations start here. Discuss fresh ideas, meet new people, and speak freely.",
      "Интересные разговоры начинаются здесь. Обсуждайте идеи и знакомьтесь с новыми людьми.",
      "Qiziqarli suhbatlar shu yerda boshlanadi. Yangi g‘oyalar va yangi do‘stlar.",
    ],
    audience: [
      "Learners aged 16+ who want more speaking practice.",
      "Студенты от 16 лет, которым нужна разговорная практика.",
      "Ko‘proq suhbat amaliyotini istagan 16 yoshdan kattalar.",
    ],
    duration: [
      "Ongoing · weekly",
      "Постоянно · еженедельно",
      "Doimiy · har hafta",
    ],
    level: "A2 – C1",
    price: "290,000",
    image: "club",
    category: "adults",
    outcomes: [
      [
        "Express opinions clearly and spontaneously",
        "Выражайте мысли ясно и спонтанно",
        "Fikrlaringizni aniq va erkin bildiring",
      ],
      [
        "Expand vocabulary through real conversations",
        "Расширяйте словарь в живом общении",
        "Jonli suhbatlar orqali lug‘atni boyiting",
      ],
      [
        "Improve pronunciation with supportive feedback",
        "Улучшайте произношение с поддержкой",
        "Yordam bilan talaffuzni yaxshilang",
      ],
    ],
    schedule: [
      "Saturday · 11:00–12:30",
      "Суббота · 11:00–12:30",
      "Shanba · 11:00–12:30",
    ],
  },
  {
    id: "business-english",
    title: ["Business English", "Деловой английский", "Biznes ingliz tili"],
    tag: ["OPEN NEW DOORS", "ОТКРЫВАЙТЕ НОВЫЕ ДВЕРИ", "YANGI IMKONIYATLAR"],
    description: [
      "Make your next move with confidence. English for meetings, presentations, and global careers.",
      "Новый шаг с уверенностью. Английский для встреч, презентаций и международной карьеры.",
      "Keyingi qadamni ishonch bilan qo‘ying. Uchrashuvlar va xalqaro karyera uchun ingliz tili.",
    ],
    audience: [
      "Working professionals and entrepreneurs aged 18+.",
      "Специалисты и предприниматели от 18 лет.",
      "18 yoshdan katta mutaxassislar va tadbirkorlar.",
    ],
    duration: ["3 months", "3 месяца", "3 oy"],
    level: "B1 – C1",
    price: "1,190,000",
    image: "business",
    category: "adults",
    outcomes: [
      [
        "Lead meetings and deliver effective presentations",
        "Ведите встречи и убедительные презентации",
        "Uchrashuvlarni olib boring va taqdimot qiling",
      ],
      [
        "Write clear professional emails and proposals",
        "Пишите деловые письма и предложения",
        "Aniq ish xatlari va takliflar yozing",
      ],
      [
        "Practise interviews and negotiation scenarios",
        "Практикуйте собеседования и переговоры",
        "Suhbat va muzokaralarni mashq qiling",
      ],
    ],
    schedule: [
      "Tue / Thu · 19:00–20:30",
      "Вт / Чт · 19:00–20:30",
      "Se / Pay · 19:00–20:30",
    ],
  },
  {
    id: "intensive-english",
    title: [
      "Intensive English",
      "Интенсивный английский",
      "Intensiv ingliz tili",
    ],
    tag: [
      "MAKE EVERY DAY COUNT",
      "КАЖДЫЙ ДЕНЬ ИМЕЕТ ЗНАЧЕНИЕ",
      "HAR KUN MUHIM",
    ],
    description: [
      "More focus. More practice. A concentrated programme for learners ready to commit.",
      "Больше внимания и практики. Насыщенная программа для мотивированных студентов.",
      "Ko‘proq e’tibor va amaliyot. O‘rganishga tayyor talabalar uchun jadal dastur.",
    ],
    audience: [
      "Motivated learners aged 16+ with time for daily study.",
      "Мотивированные студенты от 16 лет, готовые учиться каждый день.",
      "Har kuni o‘qishga tayyor 16 yoshdan katta talabalar.",
    ],
    duration: ["6 weeks / level", "6 недель / уровень", "6 hafta / daraja"],
    level: "A1 – B2",
    price: "1,390,000",
    image: "general",
    category: "adults",
    outcomes: [
      [
        "Follow an immersive daily learning routine",
        "Занимайтесь по интенсивной ежедневной программе",
        "Har kunlik jadal dasturga amal qiling",
      ],
      [
        "Build fluency through guided daily practice",
        "Развивайте беглость с ежедневной практикой",
        "Har kungi mashqlar orqali ravonlikni oshiring",
      ],
      [
        "Review progress in weekly one-to-one check-ins",
        "Оценивайте прогресс на еженедельных встречах",
        "Har hafta shaxsiy uchrashuvda natijalarni ko‘ring",
      ],
    ],
    schedule: [
      "Mon–Fri · 09:00–11:00",
      "Пн–Пт · 09:00–11:00",
      "Du–Ju · 09:00–11:00",
    ],
  },
  {
    id: "online-english",
    title: ["Online English", "Английский онлайн", "Onlayn ingliz tili"],
    tag: [
      "YOUR WORLD. YOUR CLASSROOM.",
      "ВАШ МИР. ВАШ КЛАСС.",
      "DUNYONGIZ — SINFXONANGIZ",
    ],
    description: [
      "The Imperial experience, wherever you are. Live lessons that fit around your life.",
      "Атмосфера Imperial в любой точке мира. Живые уроки в удобном ритме.",
      "Imperial tajribasi istalgan joyda. Hayotingizga mos jonli darslar.",
    ],
    audience: [
      "Learners aged 16+ who prefer studying from home.",
      "Студенты от 16 лет, предпочитающие учиться дома.",
      "Uyda o‘qishni afzal ko‘radigan 16 yoshdan kattalar.",
    ],
    duration: ["3 months / level", "3 месяца / уровень", "3 oy / daraja"],
    level: "A1 – C1",
    price: "790,000",
    image: "online",
    category: "online",
    outcomes: [
      [
        "Learn in live interactive video lessons",
        "Учитесь на живых интерактивных видеоуроках",
        "Jonli interaktiv video darslarda o‘rganing",
      ],
      [
        "Access digital materials between classes",
        "Пользуйтесь цифровыми материалами между занятиями",
        "Darslar orasida raqamli materiallardan foydalaning",
      ],
      [
        "Keep a consistent routine from anywhere",
        "Сохраняйте ритм обучения из любой точки мира",
        "Istalgan joydan muntazam o‘qing",
      ],
    ],
    schedule: [
      "Mon / Wed / Fri · 20:00–21:30",
      "Пн / Ср / Пт · 20:00–21:30",
      "Du / Chor / Ju · 20:00–21:30",
    ],
  },
];
export const teachers = [
  {
    id: "madina",
    name: "Madina Karimova",
    image: "teacher1",
    category: "IELTS",
    role: [
      "Head of IELTS",
      "Руководитель IELTS",
      "IELTS bo‘limi rahbari",
    ] as Text,
    score: "9.0",
    years: 9,
    qualification: "MA TESOL · CELTA",
    bio: [
      "Madina makes ambitious goals feel achievable. Her structured feedback helps learners turn every essay and conversation into meaningful progress.",
      "Мадина делает большие цели достижимыми. Её обратная связь превращает каждое эссе и беседу в реальный прогресс.",
      "Madina katta maqsadlarni erishiladigan qiladi. Uning aniq fikrlari har bir insho va suhbatni rivojlanish imkoniyatiga aylantiradi.",
    ] as Text,
  },
  {
    id: "james",
    name: "James Bennett",
    image: "teacher2",
    category: "General",
    role: [
      "General English mentor",
      "Преподаватель общего английского",
      "Umumiy ingliz tili ustozi",
    ] as Text,
    score: null,
    years: 8,
    qualification: "BA English · CELTA",
    bio: [
      "James brings warmth, curiosity, and real-world stories to his classes. He believes confidence comes from a classroom where everyone has a voice.",
      "Джеймс привносит тепло и живые истории в каждый урок. Он верит, что уверенность рождается там, где слышен каждый.",
      "James darslarga samimiyat va hayotiy hikoyalar olib keladi. U har bir o‘quvchining ovozi eshitilishi kerak deb hisoblaydi.",
    ] as Text,
  },
  {
    id: "aziz",
    name: "Aziz Rakhimov",
    image: "teacher3",
    category: "IELTS",
    role: [
      "IELTS & speaking specialist",
      "IELTS и разговорная практика",
      "IELTS va suhbat mutaxassisi",
    ] as Text,
    score: "8.5",
    years: 6,
    qualification: "BA Linguistics · TESOL",
    bio: [
      "Aziz turns speaking anxiety into curiosity. Expect lively discussions, practical exam strategies, and individual feedback after every mock test.",
      "Азиз превращает страх говорить в любопытство. Живые дискуссии, стратегии экзамена и персональная обратная связь после тестов.",
      "Aziz gapirish qo‘rquvini qiziqishga aylantiradi. Jonli bahslar, imtihon strategiyalari va shaxsiy fikr-mulohaza.",
    ] as Text,
  },
  {
    id: "sarah",
    name: "Sarah Collins",
    image: "teacher4",
    category: "Kids",
    role: [
      "Young learners specialist",
      "Специалист по работе с детьми",
      "Yosh o‘quvchilar mutaxassisi",
    ] as Text,
    score: null,
    years: 7,
    qualification: "BEd · TEFL Young Learners",
    bio: [
      "Sarah makes English an adventure through stories, songs, and creative projects. Every child gets the space to explore and the support to thrive.",
      "Сара превращает английский в приключение с историями, песнями и творчеством. Каждый ребёнок получает внимание и поддержку.",
      "Sarah hikoyalar, qo‘shiqlar va ijod orqali ingliz tilini sarguzashtga aylantiradi. Har bir bolaga e’tibor va yordam.",
    ] as Text,
  },
  {
    id: "dilshod",
    name: "Dilshod Akramov",
    image: "teacher5",
    category: "Business",
    role: [
      "Business English coach",
      "Преподаватель делового английского",
      "Biznes ingliz tili ustozi",
    ] as Text,
    score: "8.0",
    years: 7,
    qualification: "MBA · CELTA",
    bio: [
      "Dilshod connects language with professional life, using realistic meeting simulations and projects to help learners communicate with clarity.",
      "Дилшод связывает язык с карьерой через деловые игры и практические проекты для ясного общения.",
      "Dilshod uchrashuv mashqlari va amaliy loyihalar orqali tilni kasbiy hayot bilan bog‘laydi.",
    ] as Text,
  },
  {
    id: "nargiza",
    name: "Nargiza Usmanova",
    image: "teacher6",
    category: "General",
    role: [
      "General & online English",
      "Общий английский и онлайн",
      "Umumiy va onlayn ingliz tili",
    ] as Text,
    score: "8.5",
    years: 5,
    qualification: "MA Applied Linguistics · TESOL",
    bio: [
      "Nargiza creates thoughtful lessons that make complex language simple. Her online classes are collaborative, personal, and full of practical ideas.",
      "Наргиза делает сложное понятным. Её онлайн-уроки — это сотрудничество, индивидуальный подход и практические идеи.",
      "Nargiza murakkab tilni sodda qiladi. Uning onlayn darslari hamkorlik, shaxsiy e’tibor va amaliy g‘oyalarga boy.",
    ] as Text,
  },
  {
    id: "oliver",
    name: "Oliver Hughes",
    image: "teacher7",
    category: "IELTS",
    role: [
      "Academic writing mentor",
      "Преподаватель академического письма",
      "Akademik yozuv ustozi",
    ] as Text,
    score: null,
    years: 10,
    qualification: "MA Education · DELTA",
    bio: [
      "Oliver helps learners organise their ideas and write with purpose. He brings a patient, analytical approach to academic English and IELTS writing.",
      "Оливер помогает структурировать мысли и писать осмысленно. Терпеливый аналитический подход к академическому английскому и IELTS.",
      "Oliver fikrlarni tartibga solish va maqsadli yozishga yordam beradi. Akademik ingliz tiliga sabrli va tahliliy yondashuv.",
    ] as Text,
  },
  {
    id: "zebo",
    name: "Zebo Saidova",
    image: "teacher8",
    category: "Kids",
    role: [
      "Kids & teens English",
      "Английский для детей и подростков",
      "Bolalar va o‘smirlar ingliz tili",
    ] as Text,
    score: "8.0",
    years: 4,
    qualification: "BA Education · TEFL",
    bio: [
      "Zebo balances joyful activities with clear learning goals. She helps young learners develop independence and celebrate small wins every week.",
      "Зебо сочетает увлекательные занятия с ясными целями. Дети учатся самостоятельности и радуются маленьким победам каждую неделю.",
      "Zebo qiziqarli mashg‘ulotlarni aniq maqsadlar bilan birlashtiradi. Bolalar mustaqillikni o‘rganadi va kichik yutuqlarni nishonlaydi.",
    ] as Text,
  },
];
export type Teacher = (typeof teachers)[number];
export const students = [
  {
    name: "Sevinch A.",
    score: 8.5,
    image: "student1",
    start: "6.0",
    skills: [9, 9, 7.5, 8.5],
    quote: [
      "I stopped memorising answers and started finding my own voice. That changed everything.",
      "Я перестала заучивать ответы и нашла свой голос. Это изменило всё.",
      "Javoblarni yodlashni to‘xtatib, o‘z fikrimni ifodalashni boshladim. Bu hammasini o‘zgartirdi.",
    ] as Text,
    goal: [
      "A new chapter at university",
      "Новая глава в университете",
      "Universitetdagi yangi bosqich",
    ] as Text,
  },
  {
    name: "Javohir M.",
    score: 8,
    image: "student2",
    start: "5.5",
    skills: [8.5, 8.5, 7, 8],
    quote: [
      "Weekly feedback made my progress visible. One small improvement at a time added up to a big result.",
      "Еженедельная обратная связь показала мой прогресс. Маленькие улучшения привели к большому результату.",
      "Har haftalik fikrlar rivojlanishimni ko‘rsatdi. Kichik qadamlar katta natijaga olib keldi.",
    ] as Text,
    goal: [
      "Ready for a global career",
      "Готов к международной карьере",
      "Xalqaro karyeraga tayyor",
    ] as Text,
  },
  {
    name: "Shahnoza R.",
    score: 8.5,
    image: "student3",
    start: "6.5",
    skills: [9, 8.5, 7.5, 8.5],
    quote: [
      "The best part was the people. We practised together, encouraged each other, and grew together.",
      "Лучшее — это люди. Мы вместе практиковались, поддерживали друг друга и росли.",
      "Eng yaxshisi odamlar edi. Birga mashq qildik, bir-birimizni qo‘llab-quvvatladik va rivojlandik.",
    ] as Text,
    goal: [
      "From ambition to opportunity",
      "От амбиций к возможностям",
      "Maqsaddan imkoniyatga",
    ] as Text,
  },
];
export const gallery = [
  {
    image: "classroom",
    category: "Spaces",
    title: [
      "Room to grow",
      "Пространство для роста",
      "Rivojlanish uchun makon",
    ] as Text,
  },
  {
    image: "hero",
    category: "Community",
    title: [
      "Better, together",
      "Вместе — лучше",
      "Birgalikda yaxshiroq",
    ] as Text,
  },
  {
    image: "general",
    category: "Learning",
    title: [
      "Every conversation counts",
      "Важен каждый разговор",
      "Har bir suhbat muhim",
    ] as Text,
  },
  {
    image: "club",
    category: "Community",
    title: [
      "Find your people",
      "Найдите своих людей",
      "O‘z do‘stlaringizni toping",
    ] as Text,
  },
  {
    image: "kids",
    category: "Learning",
    title: [
      "Curiosity in action",
      "Любознательность в действии",
      "Amaldagi qiziquvchanlik",
    ] as Text,
  },
  {
    image: "library",
    category: "Spaces",
    title: [
      "A quiet moment of focus",
      "Минута сосредоточенности",
      "Diqqat va xotirjamlik",
    ] as Text,
  },
  {
    image: "business",
    category: "Learning",
    title: [
      "Ideas without borders",
      "Идеи без границ",
      "Chegarasiz g‘oyalar",
    ] as Text,
  },
  {
    image: "event",
    category: "Community",
    title: [
      "More than a classroom",
      "Больше, чем класс",
      "Sinfxonadan ham ko‘proq",
    ] as Text,
  },
];
export const branches = [
  {
    id: "oybek",
    name: "Oybek",
    district: [
      "Mirobod district",
      "Мирабадский район",
      "Mirobod tumani",
    ] as Text,
    image: "classroom",
  },
  {
    id: "yunusabad",
    name: "Yunusabad",
    district: [
      "Yunusabad district",
      "Юнусабадский район",
      "Yunusobod tumani",
    ] as Text,
    image: "library",
  },
  {
    id: "chilanzar",
    name: "Chilanzar",
    district: [
      "Chilanzar district",
      "Чиланзарский район",
      "Chilonzor tumani",
    ] as Text,
    image: "general",
  },
];
export const faq: { q: Text; a: Text }[] = [
  {
    q: [
      "I’m a complete beginner. Can I join?",
      "Я начинающий. Можно ли записаться?",
      "Men boshlovchiman. Qatnashsam bo‘ladimi?",
    ],
    a: [
      "Absolutely. General English starts at A1. A short level conversation helps find a comfortable group and a sensible starting point.",
      "Конечно. Общий английский начинается с A1. Короткая беседа поможет выбрать подходящую группу и начальный уровень.",
      "Albatta. Umumiy ingliz tili A1 dan boshlanadi. Qisqa suhbat mos guruh va boshlang‘ich darajani aniqlashga yordam beradi.",
    ],
  },
  {
    q: [
      "What happens in the free trial lesson?",
      "Как проходит бесплатный пробный урок?",
      "Bepul sinov darsi qanday o‘tadi?",
    ],
    a: [
      "The proposed trial includes a level conversation, a sample group activity, and a chat about your goals. This demonstration website does not create a real booking.",
      "Пробный урок включает определение уровня, групповое задание и обсуждение целей. Этот демонстрационный сайт не создаёт реальное бронирование.",
      "Sinov darsi darajani aniqlash, guruh mashqi va maqsadlar haqida suhbatni o‘z ichiga oladi. Bu namuna sayti haqiqiy darsni band qilmaydi.",
    ],
  },
  {
    q: [
      "How many students are in each group?",
      "Сколько студентов в группе?",
      "Har guruhda nechta o‘quvchi bor?",
    ],
    a: [
      "The sample programme is designed for 8–12 learners per group, leaving room for individual feedback and plenty of speaking time.",
      "Пример программы рассчитан на 8–12 студентов, чтобы у каждого было время для практики и персональной обратной связи.",
      "Namuna dasturi har guruhda 8–12 o‘quvchiga mo‘ljallangan. Bu shaxsiy fikr va suhbat uchun yetarli vaqt beradi.",
    ],
  },
  {
    q: [
      "Can you guarantee an IELTS score?",
      "Можно ли гарантировать балл IELTS?",
      "IELTS ballini kafolatlaysizmi?",
    ],
    a: [
      "No score is guaranteed. Outcomes depend on your starting level, attendance, practice, and test performance. Displayed success stories are fictional examples.",
      "Баллы не гарантируются. Результат зависит от уровня, посещаемости, практики и экзамена. Истории успеха на сайте вымышлены.",
      "Ball kafolatlanmaydi. Natija darajangiz, qatnashish, mashqlar va imtihonga bog‘liq. Saytdagi muvaffaqiyat hikoyalari xayoliy.",
    ],
  },
  {
    q: [
      "Can I study online or after work?",
      "Можно ли учиться онлайн или после работы?",
      "Onlayn yoki ishdan keyin o‘qisam bo‘ladimi?",
    ],
    a: [
      "Yes. Explore the Online English programme or the sample evening schedules on each course page. Exact groups and availability would be confirmed by an advisor.",
      "Да. Посмотрите онлайн-курс или примеры вечернего расписания на страницах курсов. Наличие групп уточняется у консультанта.",
      "Ha. Onlayn kursni yoki kurs sahifalaridagi kechki jadvallarni ko‘ring. Aniq guruh va vaqt maslahatchi bilan kelishiladi.",
    ],
  },
];
